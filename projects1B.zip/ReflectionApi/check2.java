class CheckClass
{
public CheckClass()
{
}
public CheckClass(int a,int b)
{
}
}