import java.lang.Class;
import java.lang.reflect.Method;
class psp
{
public static void main(String gg[])
{
try{
Class c=Class.forName(gg[0]);
Method m[]=c.getDeclaredMethods();
for(int i=0;i<m.length;i++) System.out.println(m[i].toString());
}catch(Exception e)
{
System.out.println(e);
}
}
}