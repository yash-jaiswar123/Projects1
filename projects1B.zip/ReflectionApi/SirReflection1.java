class A
{}
class DemoGetClass
{
void show(Object o)
{
Class c=o.getClass();
System.out.println(c.getName());
}
public static void main(String gg[])
{

}
}
/*Determining the class Object
boolean isInterface() ->specified class object represent interface or not
boolean isArray()- class object represent array object or not
boolean isPrimitive()- class object represents primitive or not
*/