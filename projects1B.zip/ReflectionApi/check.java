class Base
{
public void publicBaseMethod()
{
System.out.println("public Base Method");
}
private void privateBaseMethod()
{
System.out.println("private Base Method");
}
protected void protectedBaseMethod()
{
System.out.println("protected Base Method");
}
void defaultBaseMethod()
{
System.out.println("Default Base Method");
}
}
class Derived extends Base
{
public void publicDerivedMethod()
{
System.out.println("public Derived Method");
}
private void privateDerivedMethod()
{
System.out.println("private Derived Method");
}
protected void protectedDerivedMethod()
{
System.out.println("protected Derived Method");
}
void defaultDerivedMethod()
{
System.out.println("Default Derived Method");
}
}