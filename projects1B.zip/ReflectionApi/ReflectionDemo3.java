import java.lang.reflect.*;
class ReflectionDemo3
{
public static void main(String gg[])  throws ClassNotFoundException
{
Class c=Class.forName("CheckClass");
Constructor c1[]=c.getConstructors();
for(int i=0;i<c1.length;i++)
System.out.println(c1[i]);
}
}