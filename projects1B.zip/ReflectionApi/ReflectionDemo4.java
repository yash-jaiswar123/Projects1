import java.lang.reflect.*;
class ReflectionDemo4
{
public static void main(String gg[]) throws ClassNotFoundException
{
Class c=Class.forName("java.lang.String");
Method m1[]=c.getDeclaredMethods();
Method m2[]=c.getMethods();
Constructor c1[]=c.getConstructors();
Field f[]=c.getFields();
for(int i=0;i<m1.length;i++)
{
System.out.println("Methods in class is :"+m1[i]);
}
for(int i=0;i<m2.length;i++)
{
System.out.println("Inherited Methods in class is :"+m2[i]);
}
for(int i=0;i<c1.length;i++)
{
System.out.println("Constructors in class is :"+c1[i]);
}
for(int i=0;i<f.length;i++)
{
System.out.println("Fields in class is :"+f[i]);
}
System.out.println("Class is :"+c.getClass());
System.out.println("Class Name is :"+c.getName());
}
}