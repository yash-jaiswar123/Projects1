import java.lang.Class;
import java.lang.reflect.Method;
class ReflectionDemo2
{
public static void main(String gg[]) throws ClassNotFoundException
{
Class c=Class.forName("Derived");//present in check.java
Method m[]=c.getMethods();
Method m1[]=c.getDeclaredMethods();
/*for(int i=0;i<m.length;i++)
{
System.out.println("Methods using getMethod() :"+m[i]);
}*/
for(int i=0;i<m1.length;i++)
{
System.out.println("Methods using getDeclaredMethod() :"+m1[i]);
}

}
}