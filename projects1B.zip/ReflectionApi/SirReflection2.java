class A
{}
interface B{}
class DemoGetClass
{
public static void main(String gg[]) throws ClassNotFoundException	
{
Class c=Class.forName("A");
System.out.println(c.isInterface());
Class c1=Class.forName("B");
System.out.println(c1.isInterface());
int arr[]=new int[4];
System.out.println(arr.getClass().isArray());
System.out.println(c1.isArray());
Class c2=Class.forName("java.lang.String");
System.out.println(c2.getSuperclass().getName());
}
}
/*
*/