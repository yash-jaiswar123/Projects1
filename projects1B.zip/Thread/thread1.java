class ThreadDemo extends Thread
{
public void run()
{
System.out.println("Thread started");
}
public static void main(String gg[])
{
ThreadDemo t=new ThreadDemo();
t.start();
//t.start();if we again call start() then it gives error
}
}
/*start is used to create a new thread and to make it runnable  this new thread begins inside the run() method*/
