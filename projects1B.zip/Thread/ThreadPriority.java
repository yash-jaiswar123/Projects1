class ThreadPriorityDemo extends Thread
{
public void run()
{
System.out.println("In run method");
System.out.println(Thread.currentThread().getPriority());
}
public static void main(String gg[])
{
System.out.println(Thread.currentThread().getPriority());
Thread.currentThread().setPriority(10);//(MIN_PRIORITY)
ThreadPriorityDemo t=new ThreadPriorityDemo();
t.setPriority(7);
t.start();
}
}