//multi thread multi task
class MyThread1 extends Thread
{
public void run()
{
System.out.println("I am in Thread1");
}
}
class MyThread2 extends Thread
{
public void run()
{
System.out.println("I am in Thread2");
}
}
class MyThread3 extends Thread
{
public void run()
{
System.out.println("I am in Thread3");
}
}
class psp
{
public static void main(String gg[])
{
MyThread1 m1=new MyThread1();
m1.start();
MyThread2 m2=new MyThread2();
m2.start();
MyThread3 m3=new MyThread3();
m3.start();
}
}