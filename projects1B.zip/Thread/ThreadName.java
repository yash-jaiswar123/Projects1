class ThreadNameDemo extends Thread
{
public void run()
{
//Thread.currentThread().setName("run");
System.out.println("Run :"+Thread.currentThread().getName());
}

public static void main(String gg[])
{
System.out.println(Thread.currentThread().getName());
ThreadNameDemo t1=new ThreadNameDemo();
System.out.println(t1.isAlive());
t1.setName("t1 thread");
t1.start();
System.out.println(t1.isAlive());
System.out.println(Thread.currentThread().isAlive());
ThreadNameDemo t2=new ThreadNameDemo();
t2.setName("t2 thread");
t2.start();

}
}