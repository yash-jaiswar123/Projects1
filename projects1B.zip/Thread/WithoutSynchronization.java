class BookTicket
{
int totalSeats=12;
void bookSeat(int seats)
{
if(totalSeats>=seats)
{
System.out.println("Booked Successful");
totalSeats=totalSeats-seats;
System.out.println("Remaining seats :"+totalSeats);
}
else System.out.println("Seats are not available "+totalSeats);
}
}
class TicketWithSynch extends Thread
{
static BookTicket b;
int seats;
public void run()
{
b.bookSeat(seats);
}
public static void main(String gg[])
{
b=new BookTicket();
TicketWithSynch p1=new TicketWithSynch();
p1.seats=8;
p1.start();

TicketWithSynch p2=new TicketWithSynch();
p2.seats=10;
p2.start();

}
}
