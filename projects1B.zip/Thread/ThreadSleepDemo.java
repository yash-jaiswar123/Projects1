class ThreadSleepDemo extends Thread
{
public void run()
{
for(int i=0;i<=3;i++)
{
try{
//Thread.sleep(100);
System.out.println(Thread.currentThread().getName());
}catch(Exception e)
{
e.printStackTrace();
}
System.out.println(i);
}
}
public static void main(String gg[])
{
ThreadSleepDemo t=new ThreadSleepDemo();
t.setName("Yash");
t.setPriority(10);
t.start();
ThreadSleepDemo t2=new ThreadSleepDemo();
t2.setName("Tech");
t2.setPriority(1);
t2.start();
}
}