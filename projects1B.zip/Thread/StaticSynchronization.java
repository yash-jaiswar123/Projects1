class BookTicket
{
static int totalSeats=12;
static synchronized void bookSeat(int seats)
{
if(totalSeats>=seats)
{
System.out.println("Booked successfully");
totalSeats=totalSeats-seats;
System.out.println("Remaining seats :"+totalSeats);
}
else System.out.println("Not booked :"+totalSeats);
}
}
class Thread1 extends Thread
{
static BookTicket b;
int seats;
Thread1(BookTicket b,int seats)
{
this.b=b;
this.seats=seats;
}
public void run()
{
b.bookSeat(seats);
}
}
class Thread2 extends Thread
{
static BookTicket b;
int seats;
Thread2(BookTicket b,int seats)
{
this.b=b;
this.seats=seats;
}
public void run()
{
b.bookSeat(seats);
}
}
class Thread3 extends Thread
{
static BookTicket b;
int seats;
Thread3(BookTicket b,int seats)
{
this.b=b;
this.seats=seats;
}
public void run()
{
b.bookSeat(seats);
}
}

class StaticSyncDemo
{
public static void main(String gg[])
{
BookTicket b=new BookTicket();
Thread1 t1=new Thread1(b,8);
t1.start();
Thread2 t2=new Thread2(b,3);
t2.start();
BookTicket b1=new BookTicket();
Thread1 t3=new Thread1(b,3);
t3.start();
Thread2 t4=new Thread2(b,4);
t4.start();

}
}