class A extends Thread
{
public void run()
{
try
{
for(int i=1;i<=5;i++)
{
System.out.println(i);
Thread.sleep(1000);
}
}catch(Exception e)
{
System.out.println(e);
}

}
}
class B extends Thread
{
public void run()
{
try
{
for(int i=101;i<=105;i++)
{
System.out.println(i);
Thread.sleep(1000);
}

}catch(Exception e)
{
System.out.println(e);
}
}
}
class psp
{
public static void main(String gg[])throws Exception
{
A a=new A();
B b=new B();
a.start();
a.join();
b.start();
}
}