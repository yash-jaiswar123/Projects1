import java.util.Scanner;
class A extends Thread
{
public void run()
{
for(int i=1;i<=10;i++) 
{
System.out.println(i);
}
}
}
class B extends Thread
{
public void run()
{
for(int i=500;i<=510;i++)
{
  System.out.println(i);
}
}
}
class psp
{
public static void main(String gg[])
{
A a=new A();
B b=new B();
a.setPriority(3);
b.setPriority(6);
a.start();
b.start();
}
}