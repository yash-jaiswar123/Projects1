class InterruptedDemo1 extends Thread
{
public void run()
{
try{
for(int i=1;i<=5;i++)
{
System.out.println(i);
//Thread.sleep(2000);
}
}catch(Exception e)
{
System.out.println(e);
}
}
public static void main(String gg[])
{
InterruptedDemo1 i=new InterruptedDemo1();
i.start();
i.interrupt();
}
}