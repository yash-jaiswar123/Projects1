class InterruptedDemo2 extends Thread
{
public void run()
{
try{
System.out.println(Thread.currentThread().isInterrupted());
for(int i=1;i<=5;i++)
{
System.out.println(i);
Thread.sleep(2000);
}
}catch(Exception e)
{
System.out.println(e);
}
}
public static void main(String gg[])
{
InterruptedDemo2 i=new InterruptedDemo2();
i.start();
i.interrupt();
}
}