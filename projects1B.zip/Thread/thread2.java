class ThreadDemo implements Runnable
{
public void run()
{
System.out.println("Thread started");
}
public static void main(String gg[])
{
Thread t=new Thread(new ThreadDemo());
t.start();
}
}
/*start is used to call the run() when start is called a new stack is given to the thread and run() is invoked a new thread */