class JoinDemo extends Thread
{
static Thread mt;
public void run()
{
try{
mt.join();
for(int i=1;i<=3;i++)
{
System.out.println("run thread :"+i);
Thread.sleep(1000);
}

}catch(Exception e)
{
System.out.println(e);
}
}
public static void main(String gg[]) throws Exception
{
mt=Thread.currentThread();
JoinDemo jd=new JoinDemo();
jd.start();
//jd.join();
try{
for(int i=1;i<=3;i++)
{
System.out.println("main thread :"+i);
Thread.sleep(1000);
}

}catch(Exception e)
{
System.out.println(e);
}



}

}