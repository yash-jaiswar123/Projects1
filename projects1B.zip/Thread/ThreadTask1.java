//single thread single task
//single task and multiple thread
class ThreadDemo extends Thread
{
public void run()
{
System.out.println("Thread started");
}
public static void main(String gg[])
{
ThreadDemo t=new ThreadDemo();
t.start();
Thread t1=new ThreadDemo();
t1.start();
}
}