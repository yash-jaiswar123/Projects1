class DaemonDemo1 extends Thread
{
public void run()
{
//System.out.println("In run method");
if(Thread.currentThread().isDaemon())
 System.out.println("I am Daemon");
else System.out.println("I am not daemon");
}
public static void main(String gg[])
{
System.out.println("Main thread");
DaemonDemo1 d=new DaemonDemo1();
d.setDaemon(true);
d.start();
}
}