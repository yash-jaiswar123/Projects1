class Bullet extends Thread
{
int total=100;
synchronized public void fire(int bullets)
{
 for(int i=1;i<=total;i++)
 {
  if(i==bullets)
  {
   System.out.println("Bullets fired :"+bullets);
   System.out.println(Thread.currentThread().getState());
   try{
   Thread.currentThread().wait();
   }catch(Exception e)
   {
   System.out.println(e);
   }
  } 
 }
}

synchronized public void fireStart(int bullets)
{
fire(bullets);
}
}

class psp
{
public static void main(String gg[])
{
Bullet b=new Bullet();
new Thread(){
public void run()
{
b.fire(30);
}
}.start();

new Thread(){
public void run()
{
b.fire(40);
}
}.start();



}
}