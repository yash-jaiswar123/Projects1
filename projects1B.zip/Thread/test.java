class BookTicket
{
static int totalSeats=100;
static synchronized public void bookTicket(int seats)
{
if(seats<=totalSeats)
{
totalSeats-=seats;
System.out.println("Ticket Booked successfully");
System.out.println("Remaining seats is :"+totalSeats);
}
else System.out.println("Only "+totalSeats+" are empty");
}
}
class Thread1 extends Thread
{
BookTicket b;
int seats;
Thread1(BookTicket t,int s)
{
this.b=t;
this.seats=s;
}
public void run()
{
this.b.bookTicket(this.seats);
}
}

class Thread2 extends Thread
{
BookTicket b;
int seats;
Thread2(BookTicket t,int s)
{
this.b=t;
this.seats=s;
}
public void run()
{
this.b.bookTicket(this.seats);
}
}

class Thread3 extends Thread
{
BookTicket b;
int seats;
Thread3(BookTicket t,int s)
{
this.b=t;
this.seats=s;
}
public void run()
{
this.b.bookTicket(this.seats);
}
}
class psp
{
public static void main(String gg[])
{
BookTicket b=new BookTicket();
Thread1 t1=new Thread1(b,50);
Thread2 t2=new Thread2(b,30);
Thread3 t3=new Thread3(b,60);
t1.start();
t2.start();
t3.start();
BookTicket b1=new BookTicket();
Thread1 t4=new Thread1(b1,55);
Thread2 t5=new Thread2(b1,75);
Thread3 t6=new Thread3(b1,65);
t4.start();
t5.start();
t6.start();
}
}