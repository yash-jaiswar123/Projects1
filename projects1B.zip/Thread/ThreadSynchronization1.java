class Medium
{
public int produce;
public void setProduce(int pro)
{
this.produce=pro;
}
public int getProduce()
{
return this.produce;
}
}
class Producer extends Thread
{
public Medium m;
Producer(Medium m)
{
this.m=m;
}
public void run()
{
for(int i=1;i<=10;i++)
{
System.out.println("Producer produce :"+i);
m.setProduce(i);
}
}
}
class Consumer extends Thread
{
public Medium m;
Consumer(Medium m)
{
this.m=m;
}
public void run()
{
for(int i=1;i<=10;i++)
{
System.out.println("Consumer :"+m.getProduce());
}
}

}

class ThreadSyncDemo extends Thread
{
public static void main(String gg[])
{
Medium m=new Medium();
Producer p=new Producer(m);
Consumer c=new Consumer(m);
p.start();
c.start();
}
}