import com.yash.tech.*;
class packageDemo
{
public static void main(String gg[])
{
Test t=new Test();
}
}