//import javax.swing.JOptionPane;
import javax.swing.*;
class eg1
{
public static void main(String gg[])
{
JFrame jf=new JFrame();
jf.setSize(500,500);
//JOptionPane.showMessageDialog(jf,"hello");

String name=JOptionPane.showInputDialog(jf,"Name");
JLabel jb=new JLabel(name);
jf.add(jb);
//JPanel jp=new JPanel();
//jp.add(jb);
//jf.getContentPane().add(jp);
System.out.println(name);
jf.setVisible(true);
//System.exit(0);
}
}