import javax.swing.*;
import java.awt.*;
class psp
{
public static void main(String gg[])
{
String city[]=new String[]{"Ujjain","Indore","Bhopal"}; 
JFrame frame=new JFrame();
JLabel nameLabel=new JLabel("Name");
frame.setLayout(new FlowLayout());
frame.add(nameLabel);

JTextField nameTextField=new JTextField(15);
frame.add(nameTextField);

JLabel addressLabel=new JLabel("Adress");
frame.add(addressLabel);

JTextArea jt=new JTextArea();
jt.setSize(100,100);
jt.setLineWrap(true);
frame.add(jt);

JLabel genderLabel=new JLabel("Gender");
frame.add(genderLabel);


JRadioButton maleRadioButton=new JRadioButton("Male");
JRadioButton femaleRadioButton=new JRadioButton("Female");
frame.add(maleRadioButton);
frame.add(femaleRadioButton);


JLabel cityLabel=new JLabel("City");
frame.add(cityLabel);

JComboBox cityComboBox=new JComboBox(city);
frame.add(cityComboBox);




frame.setSize(600,600);
frame.setLocation(500,300);
frame.setVisible(true);
frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
}
}