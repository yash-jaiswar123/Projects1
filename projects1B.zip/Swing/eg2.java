import javax.swing.*;
class check
{
public static void main(String gg[])
{
JFrame jf=new JFrame("Welcome");
jf.setSize(500,500);
jf.setVisible(true);
//JButton b=new JButton("Check");
String name=JOptionPane.showInputDialog(jf,"Name");
//jf.add(b);
jf.setVisible(true);
}
}