package com.yash.orm.SpringAOP1;

public interface PaymentServiceInterface {
public void makePayment();
public void makePayment1(int amount);

public int ranking(int noOfViews,int watchTime);

}
