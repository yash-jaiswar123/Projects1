package com.yash.orm.SpringAOP1;

public class PaymentService implements PaymentServiceInterface{

	public void makePayment() {
		
		//Payment code
		System.out.println("Amount Debited...");
		//processes
		//
		//
		System.out.println("Amount Credited....");
		
	}

	public void makePayment1(int amount) {
		// TODO Auto-generated method stub
		System.out.println(amount +" amount debited");
		//processes
		System.out.println(amount+" amount credited");
	}
	
	//Below is used to check @Around Annotation

	public int ranking(int noOfViews, int watchTime) {
		
		System.out.println("Views :"+noOfViews+" Watch time :"+watchTime);
		int rank=noOfViews*watchTime;
		return rank;
	}

}
