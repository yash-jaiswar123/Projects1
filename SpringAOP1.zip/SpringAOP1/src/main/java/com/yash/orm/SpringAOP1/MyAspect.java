package com.yash.orm.SpringAOP1;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class MyAspect {

	@Before("execution(* PaymentService.makePayment())")//if it is in package the we write with package name
	public void printBefore()
	{
		System.out.println("Payment started");
		System.out.println("User Authenticated");
		
	}
	@After("execution(* PaymentService.makePayment())")//if it is in package the we write with package name
	public void printAfter()
	{
		System.out.println("Payment Finished");
		System.out.println("User Logout");
		
	}
	
	@After("execution(* PaymentService.makePayment1(..))")
	public void printAfter1()
	{
		System.out.println("After make Payment1");
	}

	@Before("execution(* PaymentService.makePayment1(..))")
	public void printBefore1()
	{
		System.out.println("Before make Payment1");
	}
	
	@Pointcut("execution(* PaymentService.makePayment())")
	public void pointCut() {}
	@Before("pointCut()")
	public void beforeJoinCut()
	{
		System.out.println("Before point cut");
	}
	@After("pointCut()")
	public void afterJoinCut()
	{
		System.out.println("After point cut");
	}
	
	/* Below @Around annotation is execute before the service method*/
	
	@Around("execution(* PaymentService.ranking(int,int))")
	public Object aroundCheck(ProceedingJoinPoint pjf)
	{
		Object[] arg=pjf.getArgs();
		arg[0]=Integer.parseInt(arg[0]+"")-50;
		arg[1]=Integer.parseInt(arg[1]+"")-5;
		Object o=null;
		try {
			o=pjf.proceed(arg);
		}catch(Throwable t)
		{
			System.out.print(t);
		}
		return o;
	}
	
}
