package com.yash.orm.SpringAOP1;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App 
{
    public static void main( String[] args )
    {
       ApplicationContext context = new ClassPathXmlApplicationContext("config.xml");
       PaymentServiceInterface p=context.getBean("payment",PaymentServiceInterface.class);
       //auth, print:PaymentStarted
       
  //     p.makePayment();//join point
       
  //   p.makePayment1(2000);
       //Below code is used to check working of around advice
       int rank=p.ranking(100, 10);
       System.out.println(rank);
    }
}
