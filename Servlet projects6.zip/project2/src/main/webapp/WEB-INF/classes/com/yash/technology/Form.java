package com.yash.technology;
import java.io.PrintWriter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Form extends HttpServlet{
	public void doGet(HttpServletRequest request,HttpServletResponse response)
	{
		try {
		//	response.setContentType("text/html");
			PrintWriter pw=reponse.getWriter();
			pw.println("<!doctype html>");
			pw.println("<html>");
			pw.println("<head>");
			pw.println("</head>");
			pw.println("<body>");
			pw.println("<h1>Thinking machines</h1>");

			pw.println("</body>");
			pw.println("</html>");
		}catch(Exception e)
		{
			System.out.println(e);
		}
	}

}
