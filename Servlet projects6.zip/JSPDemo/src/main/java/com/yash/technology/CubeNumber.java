package com.yash.technology;
import javax.servlet.jsp.*;
import javax.servlet.jsp.tagext.*;
public class CubeNumber {
	private int number;
	public void setNumber(int number)
	{
		this.number=number;
	}
	public int doStartTag() throws JspException
	{
//	JspWriter out=PageContext.PAG;	
	}

}
