var script = document.createElement('script');
script.src = 'C:/JQuery/jQuery.js';
script.type = 'text/javascript';
document.getElementsByTagName('head')[0].appendChild(script);
    
function validate(frm)
    {
        var firstName=frm.fName.value;
        var lastName=frm.lName.value;
        var email=document.getElementById("mail").value;
        var password=frm.pass.value;
        var confirmPassword=frm.cPass.value;
        var gender=frm.gender.value;
        var source=frm.source.value;
        var income=frm.income.value;
        var age=frm.age.value;
        var bio=frm.bio.value;
        var file=frm.picture.value;
        //alert(frm.music.checked);
       if(firstName.length==0)
        {
        alert("Please enter the first name");
        return false;
        }
        if(lastName.length==0)
        {
        alert("Plase enter the last name");
        return false;
        }
        if(email.length==0)
        {
        alert("Plase enter the Email");
        return false;
        }
        if(password.length<=5 || confirmPassword.length<=5)
        {
        alert("Password must have atleast 5 characters");
        return false;
        }
        if(parseInt(age)<=0 || parseInt(age)>99)
        {
            alert("Please insert correct Age");
            return false;
        }
        if(password!=confirmPassword)
        {
            alert("Password does not match");
            return false;
        }
        if(source==-1)
        { 
	    alert("Please Select source of income")
	 return false;
         }
        if(!validateEmail(email))
        {
            return false;
        }
        if(!frm.music.checked && !frm.movies.checked && !frm.travel.checked && !frm.sport.checked)
        {
            alert("Atleast one hobbie field should be check");
            return false;
        }
        return true;
    }
    function validateEmail(email)
    {
        var pattern="[a-zA-Z]+.+[a-zA-Z]+@+[yash]+.+[com]";
        if(email.match(pattern)==null)
        {
            alert("Please enter correct email in Yash Format");
            return false;
        }
        else 
        {
            //alert("correct email");
        return true;
    }
    }