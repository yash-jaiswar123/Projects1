package com.yash.technology;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;
/**
 * Servlet implementation class YashForm
 */
@WebServlet("/YashForm")
public class YashForm extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public YashForm() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
	
		String name=request.getParameter("name");
		String pass=request.getParameter("password");
		String mail=request.getParameter("gmail");
		String url=request.getParameter("urlId");
		String city=request.getParameter("city");
		String gender=request.getParameter("gender");
		PrintWriter pw=response.getWriter();
		response.setContentType("text/html");
		pw.println("<h1 align='center'>Confirmation page</h1>");
		pw.println("<h3>Name :"+ name+"<h3>");
		pw.println("<h3>Password :"+ pass+"<h3>");
		pw.println("<h3>Mail :"+ mail+"<h3>");
		pw.println("<h3>Linked in :"+ url+"<h3>");
		pw.println("<h3>City :"+ city+"<h3>");
		pw.println("<h3>Gender :"+ gender+"<h3>");
		pw.print("<button type='button'>Add</button>");
		String c="FormServlet/Form.html";
		pw.println("<button type='button' onclick="+c+">Cancel</button>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
