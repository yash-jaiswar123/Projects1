package com.org.yash;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.org.yash.service.UserService;

@Controller
public class AddController
{
	@Autowired
	private UserService userService;
	
	@ModelAttribute
	public void commonData(Model m)
	{
		m.addAttribute("Header","Yash learning");
		m.addAttribute("desc", "home for programmer");
		System.out.println("Adding common data");
	}
 
	@RequestMapping("/frm")
	public String form()
	{
		return "form.jsp";
	}
	@RequestMapping(path="/processForm",method=RequestMethod.POST)
	public String handle(@ModelAttribute("user") User user,BindingResult result,Model m)
	{
		if(result.hasErrors())
		{
			return "form.jsp";
		}
		System.out.println(user);
		this.userService.createUser(user);
		System.out.println(user);
		m.addAttribute("user",user);
		return "success.jsp";
	}
	
	@RequestMapping("/disp")
	public String display(Model m)
	{
		List <User> lst=this.userService.getUsers();
		m.addAttribute("lst", lst);
		return "display.jsp";
	}

	@RequestMapping(path="/del")
	public String delete(HttpServletRequest request)
	{
		int id=Integer.parseInt(request.getParameter("uid"));
		this.userService.deleteData(id);
		return "loginPage.jsp";
	}
	@RequestMapping(path="/upd",method=RequestMethod.POST)
	public String update(HttpServletRequest request,Model m)
	{
		User u=new User();
		u.setName(request.getParameter("name"));
		u.setEmail(request.getParameter("email"));
		u.setAge(Integer.parseInt(request.getParameter("age")));
		u.setId(Integer.parseInt(request.getParameter("id")));
		System.out.println();
		this.userService.updateUser(u);
		return "loginPage.jsp";
	}
	
	@RequestMapping(path="/validate",method=RequestMethod.POST)
	public String valid(@ModelAttribute("aut") Authenticate aut,Model m)
	{
		System.out.println(aut);
		int i=this.userService.authorize(aut);
		System.out.println(i);
		if(i==1)
		return "loginPage.jsp";
		else 
			return ""; 
	}
	
}


//@RequestParam("emp") Employee empl
//emp is for form and empl is variable
/*by using request param 
 *@RequestMapping(path="/processForm",method=RequestMethod.POST)
	public String handleForm(@RequestParam(name="email",required=true) String name,@RequestParam("password") String pass,Model m)
{
		System.out.println("Name : "+name);
		m.addAttribute("name",name);
	return "success.jsp";
} 
 * 
 * */
 