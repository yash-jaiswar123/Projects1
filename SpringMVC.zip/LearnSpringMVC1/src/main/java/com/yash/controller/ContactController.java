package com.yash.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.yash.model.User;
import com.yash.service.UserService;

@Controller
public class ContactController {
	@Autowired
	private UserService service;
	
	@RequestMapping("/contact")
public String showForm()
{
	return "contact";
}
	//we can also use HttpServletRequest 
	/*
	 * @RequestMapping(path="/processform",method=RequestMethod.POST)
	public String handleForm(@RequestParam ("email") String email,
			@RequestParam ("username") String username,
			@RequestParam ("password") String password,Model m)
	{
		System.out.println("User email "+email);
		System.out.println("User name "+username);
		System.out.println("User password "+password);
		m.addAttribute("email",email);
		m.addAttribute("username", username);
		m.addAttribute("password", password);
		return "success";
	}*/
	
	@RequestMapping(path="/processform",method=RequestMethod.POST)
	public String handleForm(@ModelAttribute("user") User user,Model m)
	{
		m.addAttribute("user",user);
		this.service.createUser(user);
		return "success";
	}
}
