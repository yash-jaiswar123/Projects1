package com.yash.controller;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HomeController {

	@RequestMapping("/home")
	public String home()
	{
		
		System.out.println("This is home url");
		return "index";
	}
	@RequestMapping("/about")
	public String about(Model m)
	{
		System.out.println("This is about");
		m.addAttribute("name", "Yash Jaiswar");
		List<String> lst=new ArrayList<>();
		lst.add("Java");
		lst.add("AI");
		lst.add("Cloud Computing");
		m.addAttribute("l",lst);
		return "about";
	}
	@RequestMapping("/help")
	public ModelAndView help()
	{
		System.out.println("This is help controller");
		ModelAndView mav=new ModelAndView();
		mav.setViewName("help");
		mav.addObject("name","yash jaiswar");
		mav.addObject("Eid",1014829);
		LocalDateTime now=LocalDateTime.now();
		mav.addObject("time",now);
		List<Integer> lst=new ArrayList<>();
		lst.add(12);
		lst.add(34);
		lst.add(45);
		mav.addObject("marks",lst);
		return mav;
	}
}
