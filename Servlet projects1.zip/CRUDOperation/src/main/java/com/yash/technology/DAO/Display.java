package com.yash.technology.DAO;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.yash.technology.DTO.*;
import java.util.List;
import java.util.LinkedList;
import java.sql.SQLException;
@WebServlet("/Display")
public class Display extends HttpServlet{
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw=response.getWriter();
		response.setContentType("text/html");
		CrudOperation co=new CrudOperation();
		List<Employee> lst=null;
		try {
		lst=co.getEmployees();
		}catch(Exception e)
		{
			System.out.println(e);
		}
		pw.println("<table>");
		pw.println("<thead>");
		pw.println("<th>ID.</th>");
		pw.println("<th>Name</th>");
		pw.println("<th>Gender</th>");
		pw.println("<th>Salary</th>");
		pw.println("</thead>");
		pw.println("<tbody>");
		for(int i=0;i<lst.size();i++)
		{
			Employee e=lst.get(i);
		pw.print("<tr>");
		pw.println("<td>"+e.getCode()+"</td>");
		pw.println("<td>"+e.getName()+"</td>");
		pw.println("<td>"+e.getGender()+"</td>");
		pw.println("<td>"+e.getSalary()+"</td>");
		pw.println("</tr>");
		}
		pw.println("</tbody>");
		pw.print("</table>");
		pw.close();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
