package com.yash.technology.DAO;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import com.yash.technology.DAO.*;
import com.yash.technology.DTO.DTOConnection;
public class AddDetails {
	public void add() throws Exception
	{
		Connection c=DTOConnection.getConnection();
		PreparedStatement ps=c.prepareStatement("insert into empCrud values(?,?,?,?)");
		ps.setInt(1, 0);
	}

}
