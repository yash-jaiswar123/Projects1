import java.sql.*;
public class CheckDemo {
public void check() throws Exception
{
	Class.forName("com.mysql.cj.jdbc.Driver");
	String user="root";
	String pass="root";
	Connection c=DriverManager.getConnection("jdbc:musql://localhost:3306/yash",user,pass);
	PreparedStatement ps=c.prepareStatement("select * from person");
	ResultSet rs=ps.executeQuery();
	while(rs.next())
	{
		System.out.println(rs.getInt(1)+" "+rs.getString(2));
	}
	c.close();
}
}
