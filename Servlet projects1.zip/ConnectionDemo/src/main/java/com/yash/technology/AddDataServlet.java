package com.yash.technology;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AddDataServlet
 */
@WebServlet("/AddDataServlet")
public class AddDataServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
	{
	try
	{
	response.setContentType("text/html");
	PrintWriter pw=response.getWriter();
	String name=request.getParameter("name");
	char gender=request.getParameter("gender").charAt(0);
	int salary=Integer.parseInt(request.getParameter("salary"));
	int code=Integer.parseInt(request.getParameter("code"));
	pw.println("Name :"+name+"<br>");
	pw.println("Code :"+code+"<br>");
	pw.println("Gender :"+gender+"<br>");
	pw.println("Salary :"+salary+"<br>");
	Employee emp=new Employee();
	emp.setCode(code);
	emp.setGender(Character.toString(gender));
	emp.setSalary(salary);
	emp.setName(name);
	int check=Operation.addData(emp);
	if(check==1)
	{
		pw.println("Data saved");
		pw.println("<a href='index.html'>Home</a>");
	}
	else
	{
		pw.println("Data not saved");
	pw.println("<a href='index.html'>Home</a>");
	}
	}catch(Exception e)
	{
		System.out.print(e);
	}
	}

}
