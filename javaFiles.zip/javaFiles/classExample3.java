class psp
{
psp()
{
System.out.println("No argument constructor");
}
psp(int n)
{
System.out.println(n);
}
public static void main(String gg[])
{
psp p=new psp();
psp p1=new psp(5);
}
}