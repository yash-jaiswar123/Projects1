class DemoWithThis
{
int i;
public void setNum(int i)
{
i=i;
}
public void show()
{
System.out.println(i);
}
public void dd()
{
System.out.println("dd");
}
private void check()
{
System.out.println("check");
}
protected void display()
{
System.out.println("Display");
}

}

class Demo
{
public static void main(String gg[])
{
DemoWithThis t=new DemoWithThis();
t.setNum(15);
t.show();
}
}