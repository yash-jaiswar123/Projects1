class psp
{
void show(int a)
{
System.out.println(a+" int");
}
void show(String a)
{
System.out.println(a+" string");
}
public static void main(String gg[])
{
psp p=new psp();
p.show('c');
}
}