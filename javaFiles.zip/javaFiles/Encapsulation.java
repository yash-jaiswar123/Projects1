class EncapExample
{
private int prop1;
private int prop2;
EncapExample()
{
this.prop1=0;
this.prop2=0;
}
public void setProp1(int prop1)
{
this.prop1=prop1;
}
public void setProp2(int prop2)
{
this.prop2=prop2;
}
public int getProp1()
{
return this.prop1;
}
public int getProp2()
{
return this.prop2;
}


public static void main(String gg[])
{
EncapExample ee=new EncapExample();
ee.setProp1(10);
ee.setProp2(20);
System.out.println(ee.getProp1()+" "+ee.getProp2());
}
}