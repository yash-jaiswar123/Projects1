interface a1
{
}
class a2
{
}
interface a3 extends a1
{
}