class A
{
public void show()
{
System.out.println("Show called in base");
}
}
class B extends A
{
public void display()
{
System.out.println("Display called");
}
public void show()
{
System.out.println("Show called in Derived");
}
}

class psp
{
public static void main(String gg[])
{
A a=new B();
a.show();
//a.display();
}
}