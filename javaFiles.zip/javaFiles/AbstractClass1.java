abstract class Vehicle
{
abstract public void start();
void show()
{
System.out.println("Show method");
}
}
class Car extends Vehicle
{
public void start()
{
System.out.println("Start by key/button");
}
}
class Bike extends Vehicle
{
public void start()
{
System.out.println("Start by key");
}
public static void main(String gg[])
{
Car c=new Car();
c.start();
c.show();
Bike b=new Bike();
b.start();
b.show();
}
}
