class psp
{
public static void main(String gg[])
{
int arr[]=new int[-5];
System.out.println(arr.length);
}
}