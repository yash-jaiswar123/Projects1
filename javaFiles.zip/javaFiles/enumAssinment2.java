class enumAssignment
{
enum Season
{
Summer(1),Winter(2),Rainy(3),Cold(4);
int val;
Season(int i)
{
this.val=i;
}
}
public static void main(String gg[])
{
Season d=Season.Winter;
switch(d)
{
case Summer:
System.out.println(d.ordinal());
System.out.println(d.val);
break;
case Winter:
System.out.println(d.ordinal());
System.out.println(d.val);
break;
case Rainy:
System.out.println(d.ordinal());
System.out.println(d.val);
break;
case Cold:
System.out.println(d.ordinal());
System.out.println(d.val);
break;
}

}
}