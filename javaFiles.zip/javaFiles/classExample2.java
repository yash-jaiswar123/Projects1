class psp
{
public void Run()
{
System.out.println("Run method invoke");
}

public static void main(String gg[])
{
System.out.println("Main method executed");
}
}