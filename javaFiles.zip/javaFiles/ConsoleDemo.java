import java.io.Console;
class ConsoleDemo
{
public static void main(String gg[])
{
String str;char ch[];
Console con=System.console();
System.out.print("Enter Username :");
str=con.readLine();
System.out.print("Enter the password :");
ch=con.readPassword();
String a=String.valueOf(ch);
System.out.println("Username :"+str+" Password :"+ch);
System.out.println("Actual Password :"+a);

}
}