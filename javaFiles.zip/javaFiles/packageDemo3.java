package mypackage1.Start;
class packageDemo
{
public static void main(String gg[])
{
Start obj=new Start();
obj.display();  
}
}