class psp
{
public static void main(String gg[])
{
System.out.println("Yash");
}
public static void main(int gg[])
{
System.out.println("Yash");
}


}