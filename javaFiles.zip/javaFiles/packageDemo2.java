import mypackage.Start;
class packageDemo2
{
public static void main(String gg[])
{
Start obj=new Start();
obj.display();
}
}
/*if i move my mypackage folder in different folder then i compile my program in two ways
1st set classpath=D:\;. temporary path
2nd permanent path ->enviroment variable in your account and set classpath
*/