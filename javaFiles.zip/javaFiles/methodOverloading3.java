class A
{
void show(StringBuffer s)
{
System.out.println("String buffer");
}
void show(String g)
{
System.out.println("String");
}
public static void main(String gg[])
{
A a=new A();
a.show("yash");//print String
a.show(new StringBuffer("yash"));//print String Buffer
}
}