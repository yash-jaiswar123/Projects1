class psp
{
public static void main(String gg[])
{

StringBuilder sb=new StringBuilder(gg[0]);
//String sb="Welcome";
System.out.println(sb.charAt(3));
System.out.println(sb.delete(0,4));
System.out.println(sb.append("Yash"));

}
}