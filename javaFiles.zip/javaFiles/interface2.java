interface A1
{
public void show();
}
interface A2 extends A1
{
public void display();
}
class psp implements A1,A2
{
public void show()
{
}
public void display()
{
}
public static void main(String gg[])
{

}
}