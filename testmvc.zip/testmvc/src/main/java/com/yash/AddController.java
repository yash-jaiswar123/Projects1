package com.yash;

import java.util.LinkedList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class AddController {

	@RequestMapping("/add")
	public ModelAndView check(HttpServletRequest request,HttpServletResponse response)
{
		
		int i=Integer.parseInt(request.getParameter("t1"));
		int j=Integer.parseInt(request.getParameter("t2"));
		int k=i+j;
		ModelAndView mv=new ModelAndView();
		mv.setViewName("display.jsp");
		mv.addObject("result",k);
	return mv;
}
	
	
	@RequestMapping("/check")
	public String check2(Model m)
	{
		
		System.out.println("this is run");
		m.addAttribute("message","this is ");
		List<String> lst=new LinkedList<String>();
		lst.add("ujjain");
		lst.add("Indore");
		lst.add("Bhopal");
		m.addAttribute("list",lst);
		return "viewpage.jsp";
	}
}
