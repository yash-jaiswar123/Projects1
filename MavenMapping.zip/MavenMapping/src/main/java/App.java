import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;  
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;  

public class App 
{
	private static SessionFactory factory; 

    public static void main( String[] args )
    {
        StandardServiceRegistry ssr=new StandardServiceRegistryBuilder().configure().build();
    	Metadata meta=new MetadataSources(ssr).getMetadataBuilder().build();
    	factory=meta.getSessionFactoryBuilder().build();
    	Employee emp=new Employee();
    	emp.setName("yash");
    	Address address=new Address();
    	address.setArea("Sandipani nagar");
    	address.setCity("ujjain");
    	address.setState("M.P.");
    	address.setPincode(456006);
    	emp.setAddress(address);
    	int code=addData(emp);
    	System.out.println("Code :"+code);
    	
    }
    public static Integer addData(Employee emp)
    {
	      Session session = factory.openSession();
	      Transaction tx = null;
	      Integer employeeID = null;
	      
	      try {
	         tx = session.beginTransaction();
	         employeeID = (Integer) session.save(emp); 
	         tx.commit();
	      } catch (HibernateException e) {
	         if (tx!=null) tx.rollback();
	         e.printStackTrace(); 
	      } finally {
	         session.close(); 
	      }
	      return employeeID;

    	
    }
}
