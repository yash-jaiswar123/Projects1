package com.yash.JerseyDemo1;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
/**
 * Root resource (exposed at "myresource" path)
 */
@Path("myresource")
public class MyResource {
    @GET
    @Produces(MediaType.APPLICATION_XML)
    public Resource1 getResource()
    {
    	System.out.println("Check message");
    	Resource1 r=new Resource1();
    	r.setName("Yash");
    	r.setMarks(93);
    	return r;
    }
}
