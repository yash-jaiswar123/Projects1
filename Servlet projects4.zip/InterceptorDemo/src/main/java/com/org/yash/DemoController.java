package com.org.yash;



import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import java.util.logging.Logger;
@Controller
@RequestMapping("/")
public class DemoController {

	private static final Logger logger = Logger.getLogger("InController");



	@RequestMapping(method = RequestMethod.GET)
	public String printStatus(ModelMap model) {
		System.out.println("In controller");
	logger.info("InController -> printStatus");
	model.addAttribute("status", "SUCCESS!");
	return "success";
	}
}
