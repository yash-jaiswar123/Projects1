function Person(firstName,lastName,age)
{
    this.firstName=firstName;
    this.lastName=lastName;
    this.age=age;
}
var a=Person("yash","jaiswar",21);
console.log(a.firstName);
console.log(a.lastName);
console.log(a.age);
