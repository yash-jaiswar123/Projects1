package com.yash.technology;

public class Employee {
private String name;
private String password;
private int code;
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public int getCode() {
	return code;
}
public void setCode(int code) {
	this.code = code;
}


}
