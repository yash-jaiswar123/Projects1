package com.yash.technology;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/CustomerAddServlet")
public class CustomerAddServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
	String name=request.getParameter("name");
	String gender=request.getParameter("gender");
	int balance=Integer.parseInt(request.getParameter("balance"));
	String password=request.getParameter("password");
	int age=Integer.parseInt(request.getParameter("age"));
	Customer c=new Customer();
	c.setAge(age);
	c.setBalance(balance);
	c.setGender(gender);
	c.setName(name);
	c.setPassword(password);
	int accountNum= DataBaseOperation.addCustomer(c);
	response.setContentType("text/html");
	PrintWriter pw=response.getWriter();
	pw.println("<h2>Customer Added with details-</h2>");
	pw.println("Name :"+name+"<br>");
	pw.println("Gender :"+gender+"<br>");
	pw.println("Age :"+age+"<br>");
	pw.println("Balance :"+balance+"<br>");
	pw.println("<h3>Account Num :"+accountNum +"</h3>");
	pw.println("<a href='EmployeeHomePage.jsp'>Home</a>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
