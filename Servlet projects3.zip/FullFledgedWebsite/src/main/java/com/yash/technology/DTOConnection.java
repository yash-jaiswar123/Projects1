package com.yash.technology;

import java.sql.Connection;
import java.sql.DriverManager;

public class DTOConnection {
public static Connection getConnection()
{
	Connection c=null;
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		String user="root";
		String pass="root";
		String url="jdbc:mysql://localhost:3306/WebSite";
		c=DriverManager.getConnection(url,user,pass);
		
	}catch(Exception e)
	{
		System.out.println(e);
	}
	return c;
}
}
