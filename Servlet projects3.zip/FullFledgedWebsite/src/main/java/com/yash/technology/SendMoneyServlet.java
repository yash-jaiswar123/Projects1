package com.yash.technology;
import com.yash.technology.*;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/SendMoneyServlet")
public class SendMoneyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public SendMoneyServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		int AccountNum=Integer.parseInt(request.getParameter("AccountNum"));
		int amount=Integer.parseInt(request.getParameter("amount"));
		String password=request.getParameter("password");
		Customer c=DataBaseOperation.getDetailsByAccountNum(AccountNum);
		PrintWriter pw=response.getWriter();
		response.setContentType("text/html");
		if(c.getBalance()<=amount)
		{
			pw.println("Invalid Amount, Please fill amount less than the balance");
			return;
		}
		int check=DataBaseOperation.getCustomerPassword(AccountNum, password);
		if(check==0)
		{
			pw.println("Invalid password");
			return;
		}
		amount=c.getBalance()-amount;
		c.setAccountNum(AccountNum);
		c.setBalance(amount);
		DataBaseOperation.editByAccountNum(AccountNum,amount);
		pw.println("<center> <b>");
		pw.println("Transaction completed<br> ");
		pw.println("Your current balance is :"+amount+"<br>");
		String url="CustomerHomePage.jsp?AccountNum="+AccountNum;
		pw.println("<a href="+url+">Home</a>");
		pw.println("</b></center>");
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
