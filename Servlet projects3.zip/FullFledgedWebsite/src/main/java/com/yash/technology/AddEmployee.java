package com.yash.technology;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

 @WebServlet("/AddEmployee")
public class AddEmployee extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		int EmpCode=DataBaseOperation.addEmployee(username,password);
		PrintWriter pw=response.getWriter();
		response.setContentType("text/html");
		pw.println("<h1>Information page</h1>");
		pw.println("<h2>Employee Added</h2><br>");
		pw.println("<h2>Employee id :"+EmpCode +"</h2>");
		pw.println("<a href='adminPage1.html'>Home</a>");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
