package com.yash.technology;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import javax.servlet.http.Cookie;

@WebServlet("/Logout")
public class Logout extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
	Cookie c=new Cookie("name","");
	c.setMaxAge(0);
	response.addCookie(c);
	PrintWriter pw=response.getWriter();
	pw.println("<h1>Logout Page</h1>");
	pw.println("<h3>You are successfully logged out<h3>");
    pw.println("Please<a href='index.html'> Click </a>to move home page");	 
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
