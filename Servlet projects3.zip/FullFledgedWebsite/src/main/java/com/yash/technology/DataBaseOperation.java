package com.yash.technology;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;
import java.util.LinkedList;
public class DataBaseOperation {

	public static String getPassword(String username)
	{
		String pass=null;
		try {
			Connection c=DTOConnection.getConnection();
			PreparedStatement ps=c.prepareStatement("select password from AdminDatabase where username=?");
			ps.setString(1, username);
			ResultSet rs=ps.executeQuery();
			if(rs.next())
				return rs.getString("password");
			else return null;
		}catch(Exception e)
		{
			System.out.println(e);
		}
		return pass;
	}
	
	public static String getEmployeePassword(String username)
	{
		String password=null;
		try
		{
			Connection c=DTOConnection.getConnection();
			PreparedStatement ps=c.prepareStatement("select password from Employee where username=?");
			ps.setString(1, username);
			ResultSet rs=ps.executeQuery();
			if(rs.next())
			{
				return rs.getString("password");
			}
		}catch(Exception e)
		{
			System.out.print(e);
		}
		return password;
	}
public static int addEmployee(String username,String password)
{
	int empCode=-1;
	try {
		Connection c=DTOConnection.getConnection();
		PreparedStatement ps=c.prepareStatement("insert into Employee(username,password) values(?,?)",Statement.RETURN_GENERATED_KEYS);
		ps.setString(1, username);
		ps.setString(2, password);
		ps.executeUpdate();
		ResultSet rs=ps.getGeneratedKeys();
		if(rs.next()) empCode=rs.getInt(1);
		
	}catch(Exception e)
	{
		System.out.println(e);
	}
	return empCode;
}
public static List<Customer> getCustomerData()
{
	List<Customer> lst=new LinkedList<>();
try {
	Customer customer=null;
	Connection c=DTOConnection.getConnection();
	PreparedStatement ps=c.prepareStatement("select * from customer");
	ResultSet rs=ps.executeQuery();
	while(rs.next())
	{
		customer =new Customer();
		customer.setAccountNum(rs.getInt("AccountNum"));
		customer.setAge(rs.getInt("age"));
		customer.setBalance(rs.getInt("balance"));
		customer.setName(rs.getString("Name"));
		customer.setGender(rs.getString("gender"));
		customer.setPassword(rs.getString("password"));
		lst.add(customer);
	}
}catch(Exception e)
{
	System.out.print(e);
}
return lst;
}
public static List<Employee> getEmployeeDetails()
{
	List<Employee> lst=new LinkedList<>();
	try {
		Connection c=DTOConnection.getConnection();
		PreparedStatement ps=c.prepareStatement("select * from Employee");
		ResultSet rs=ps.executeQuery();
		Employee e=null;
		while(rs.next())
		{
			e=new Employee();
			e.setName(rs.getString("username"));
			e.setPassword(rs.getString("password"));
			e.setCode(rs.getInt("EmpId"));
			lst.add(e);
		}
	}catch(Exception e)
	{
		System.out.println(e);
	}
	return lst;
}
public static int addCustomer(Customer customer)
{
	int accountNum=-1;
	try {
		Connection c=DTOConnection.getConnection();
		PreparedStatement ps=c.prepareStatement("insert into customer(Name,gender,balance,password,age) values(?,?,?,?,?)",Statement.RETURN_GENERATED_KEYS);
		ps.setString(1, customer.getName());
		ps.setString(2, customer.getGender());
		ps.setInt(3, customer.getBalance());
		ps.setString(4, customer.getPassword());
		ps.setInt(5, customer.getAge());
		ps.executeUpdate();
		ResultSet rs=ps.getGeneratedKeys();
		if(rs.next()) accountNum=rs.getInt(1);
		return accountNum;
	}catch(Exception e)
	{
		System.out.print(e);
	}
	return accountNum;
}

public static Customer getDetailsByAccountNum(int accountNum)
{
	Customer cus=new Customer();
	try {
		Connection c=DTOConnection.getConnection();
		PreparedStatement ps=c.prepareStatement("select * from customer where AccountNum=?");
		ps.setInt(1, accountNum);
		ResultSet rs=ps.executeQuery();
		if(rs.next())
		{
			cus.setAccountNum(accountNum);
			cus.setName(rs.getString("name"));
			cus.setGender(rs.getString("gender"));
			cus.setBalance(rs.getInt("balance"));
			cus.setAge(rs.getInt("age"));
		}
	}catch(Exception e)
	{
		System.out.println(e);
	}
	return cus;
}
public static void updateByAccountNum(Customer customer)
{
try {
	Connection c=DTOConnection.getConnection();
	PreparedStatement ps=c.prepareStatement("update customer set name=?,gender=?,age=? where AccountNum=?");
	ps.setString(1,customer.getName());
	ps.setString(2, customer.getGender());
	ps.setInt(3, customer.getAge());
	ps.setInt(4, customer.getAccountNum());
	ps.executeUpdate();		
}catch(Exception e)
{
	System.out.println(e);
}
}
public static void deleteCustomer(int accountNum)
{
	try {
		Connection c=DTOConnection.getConnection();
		PreparedStatement ps=c.prepareStatement("delete from customer where AccountNum=?");
		ps.setInt(1, accountNum);
		ps.executeUpdate();
		
		
	}catch(Exception e)
	{
		System.out.println(e);
	}
}
public static int getCustomerPassword(int accountNum,String Password)
{
	try {
		Connection c=DTOConnection.getConnection();
		PreparedStatement ps=c.prepareStatement("select * from customer where accountNum=?");
		ps.setInt(1, accountNum);
		ResultSet rs=ps.executeQuery();
		if(!rs.next())
		{
			return 0;
		}
		String cPassword=rs.getString("password");
		if(cPassword.equals(Password))
		{
			return 1;
		}
		else return 0;
	}catch(Exception e)
	{
		System.out.println(e);
	}
	return 0;
}
public static void editByAccountNum(int accountNum,int amount)
{
	try {
		Connection c=DTOConnection.getConnection();
		PreparedStatement ps=c.prepareStatement("update customer set balance=? where AccountNum=?");
		ps.setInt(1, amount);
		ps.setInt(2, accountNum);
		ps.executeUpdate();
	}catch(Exception e)
	{
		System.out.println(e);
	}
}

}
	

