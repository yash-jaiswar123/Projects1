package com.yash.technology;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/CustomerEditServlet")
public class CustomerEditServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
    int accountNum=Integer.parseInt(request.getParameter("accountNum"));
    String name=request.getParameter("name");
    int age=Integer.parseInt(request.getParameter("age"));
    String gender=request.getParameter("gender");
    PrintWriter pw=response.getWriter();
    response.setContentType("text/html");
    pw.println("<h4>Name "+name+"</h4>");
    pw.println("<h4>Age "+age+"</h4>");
    pw.println("<h4>Gender "+gender+"</h4>");
    pw.println("<h4>Account Num "+accountNum+"</h4>");
    Customer customer=new Customer();
    customer.setAccountNum(accountNum);
    customer.setAge(age);
    customer.setGender(gender);
    customer.setName(name);
    DataBaseOperation.updateByAccountNum(customer);
    pw.println("<h3>Data Updated</h3>");
    pw.println("<a href='EmployeeHomePage.jsp'>Home</a>");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
