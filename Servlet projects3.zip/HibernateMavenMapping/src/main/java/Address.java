import javax.persistence.*;
@Entity
@Table(name="Address")
public class Address {
@Column(name="area")
	private String area;
@Column(name="city")
private String city;
@Column(name="state")
private String state;
@Column(name="pincode")
private int pinCode;

@OneToOne(targetEntity=Employee.class)
private Employee employee;

@Id  
@GeneratedValue(strategy=GenerationType.AUTO)  
private int addressId;    


public int getAddressId() {
	return addressId;
}
public void setAddressId(int addressId) {
	this.addressId = addressId;
}
public Employee getEmployee() {
	return employee;
}
public void setEmployee(Employee employee) {
	this.employee = employee;
}
public String getArea() {
	return area;
}
public void setArea(String area) {
	this.area = area;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public String getState() {
	return state;
}
public void setState(String state) {
	this.state = state;
}
public int getPinCode() {
	return pinCode;
}
public void setPinCode(int pinCode) {
	this.pinCode = pinCode;
}
}
