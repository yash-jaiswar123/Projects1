import java.sql.*;
class JDBCDemo
{
public static void main(String gg[])
{
try{
Class.forName("com.mysql.cj.jdbc.Driver");
String url="jdbc:mysql://localhost:3306/yash";
String pass="root";
String user="root";
Connection c=DriverManager.getConnection(url,user,pass);
if(c!=null)
System.out.println("Connection established");
else System.out.println("Not established");
String q="select * from Employee";
Statement st=c.createStatement();
ResultSet rs=st.executeQuery(q);
while(rs.next())
{
int id=rs.getInt("EmpId");//or col number(1)
String name=rs.getString("name");
System.out.println("Employee id :"+id+" Name :"+name);
}
c.close();
}catch(Exception e)
{
System.out.println(e);
}
}
}