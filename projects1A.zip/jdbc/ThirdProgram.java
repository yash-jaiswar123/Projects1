import java.sql.*;
class ThirdProgram
{
public static void main(String gg[])
{
try
{
Connection c=null;
Class.forName("com.mysql.cj.jdbc.Driver");
String url="jdbc:mysql://localhost:3306/yash";
String user="root";
String pass="root";
c=DriverManager.getConnection(url,user,pass);
PreparedStatement ps=c.prepareStatement("insert into Employee values (?,?)");
ps.setInt(1,1005);
ps.setString(2,"Harshal Vijaywargiya");
ps.executeUpdate();
c.close();
}catch(Exception e)
{
System.out.println(e);
}
}
}