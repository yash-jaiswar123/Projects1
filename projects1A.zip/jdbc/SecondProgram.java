import java.sql.*;
class SecondProgram
{
public static void main(String gg[])
{
Connection c=null;
try
{
Class.forName("com.mysql.cj.jdbc.Driver");
String url="jdbc:mysql://localhost:3306/yash";
String user="root";
String pass="root";
c=DriverManager.getConnection(url,user,pass);
if(c==null) return;
Statement s=c.createStatement();
s.executeUpdate("insert into Employee values (1004,'Yash Mishra')");
System.out.println("Data inserted");
c.close();
}catch(Exception e)
{
}
}
}