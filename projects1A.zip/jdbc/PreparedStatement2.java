import java.sql.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
class PrepareDemo
{
public static void main(String gg[])
{
try
{
BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
int id=Integer.parseInt(br.readLine());
String name=br.readLine();
Connection c=null;
Class.forName("com.mysql.cj.jdbc.Driver");
String url="jdbc:mysql://localhost:3306/yash";
String user="root";
String pass="root";
c=DriverManager.getConnection(url,user,pass);
PreparedStatement ps=c.prepareStatement("select name from Employee where EmpId=?");
ps.setInt(1,id);
ResultSet rs=ps.executeQuery();
if(rs.next())
{
System.out.println("ID :"+id+" already exists");
c.close();
return;
}
ps=c.prepareStatement("insert into Employee values (?,?)");
ps.setInt(1,id);
ps.setString(2,name);
ps.executeUpdate();
c.close();
}catch(Exception e)
{
System.out.println(e);
}
}
}