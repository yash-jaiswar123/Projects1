import java.sql.*;
import java.io.FileReader;
class imageOpeartion
{
public static void main(String gg[])
{
try
{
FileReader fis=new FileReader("FirstProgram.java");
Connection c=null;
Class.forName("com.mysql.cj.jdbc.Driver");
String url="jdbc:mysql://localhost:3306/yash";
String user="root";
String pass="root";
c=DriverManager.getConnection(url,user,pass);
PreparedStatement ps=c.prepareStatement("insert into FileStore values(?,?)");
ps.setString(1,"checkFile");
ps.setCharacterStream(2,fis);
ps.executeUpdate();
System.out.println("Data inserted");


c.close();
}catch(Exception e)
{
System.out.println(e);
}
}
}