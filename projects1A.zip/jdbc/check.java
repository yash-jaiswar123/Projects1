import java.sql.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
class DataBaseOperation
{
private Connection c;
private String user="root";
private String pass="root";
private String url="jdbc:mysql://localhost:3306/yash";
private PreparedStatement ps;
DataBaseOpeartion()
{
Class.forName("com.mysql.cj.jdbc.Driver");
c=DriverManager.getConnecion(url,user,pass);
}
public String getDataById(int id)
{
ps=c.prepareStatement("select name from Employee where id=?");
ps.setInt(1,id);
ResultSet rs=ps.executeQuery();
if(rs.next())
{
return rs.getString("name");
}
else return null;
}
public void addData(int id,String name)
{
String cName=getDataById(id);
if(cName!=null)
{

}

}
void cleanup() throws Exception
{
System.out.println("Connection closed");
c.close();
}
}