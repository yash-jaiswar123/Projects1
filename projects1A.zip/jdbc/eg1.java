import java.sql.*;
class psp
{
public static void main(String gg[]) throws SQLException,ClassNotFoundException
{
Class.forName("com.mysql.cj.jdbc.Driver");
Connection c=DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql","root","root");
Statement s=c.createStatement();
ResultSet rs=s.executeQuery("show tables");
while(rs.next())
{
System.out.println("ss");
}
System.out.println("Connection closed");
c.close();
}
}