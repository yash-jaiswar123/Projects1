import java.sql.*;
class MetaDataDemo
{
public static void main(String gg[])
{
try{
Class.forName("com.mysql.cj.jdbc.Driver");
String url="jdbc:mysql://localhost:3306/yash";
String user="root";
String pass="root";
Connection c=DriverManager.getConnection(url,user,pass);
PreparedStatement ps=c.prepareStatement("select * from Employee");
ResultSet rs=ps.executeQuery();
ResultSetMetaData rmd=rs.getMetaData();
System.out.println("Total columns :"+rmd.getColumnCount());
System.out.println("Column Name:"+rmd.getColumnName(1));
System.out.println("Column type :"+rmd.getColumnTypeName(1));

c.close();
}catch(Exception e)
{
System.out.println(e);
}
}
}