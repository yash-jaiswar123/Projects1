import java.sql.*;
import java.io.FileInputStream;
class imageOpeartion
{
public static void main(String gg[])
{
try
{
FileInputStream fis=new FileInputStream("tiger.jpg");
Connection c=null;
Class.forName("com.mysql.cj.jdbc.Driver");
String url="jdbc:mysql://localhost:3306/yash";
String user="root";
String pass="root";
c=DriverManager.getConnection(url,user,pass);
PreparedStatement ps=c.prepareStatement("insert into image values (?,?)");
ps.setString(1,"tiger.jpg");
ps.setBinaryStream(2,fis);

ps.executeUpdate();
System.out.println("Data inserted");

ps=c.prepareStatement("select * from image");
ResultSet rs=ps.executeQuery();
while(rs.next())
{
System.out.println(rs.getString(1)+": Image : "+rs.getBinaryStream(2));
}
c.close();
}catch(Exception e)
{
System.out.println(e);
}
}
}
//for large file largeblob