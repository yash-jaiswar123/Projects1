import java.io.*;
class Employee implements Serializable//java.io.Serializable
{
int empId;
String empName;
Employee(int empId,String name)
{
this.empId=empId;
this.empName=name;
}
public String toString()
{
return this.empId+" "+this.empName;
}
}
class EmployeeObject
{
public static void main(String gg[]) throws IOException,ClassNotFoundException
{
Employee e=new Employee(101,"Yash");
System.out.println(e);
File f=new File("d:/mypackage1/xyz.txt");
f.createNewFile();
ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(f,true));
oos.writeObject(e);

ObjectInputStream ois=new ObjectInputStream(new FileInputStream(f));
Employee e1=(Employee)ois.readObject();
System.out.println(e1);
ois.close();
oos.close();
}
}