import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
class psp
{
public static void main(String gg[])
{
try
{
FileInputStream fin=new FileInputStream("d:/mypackage1/start.class");
BufferedInputStream binput=new BufferedInputStream(fin);
FileOutputStream fout=new FileOutputStream("d:/mypackage1/jj");
BufferedOutputStream boutput=new BufferedOutputStream(fout);
int i;
while((i=binput.read())!=-1) boutput.write(i);

binput.close();
fin.close();
//fout.close();
boutput.close();
}catch(Exception e)
{
e.printStackTrace();
}

}
}