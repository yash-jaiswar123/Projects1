import java.io.*;
class psp
{
public static void main(String gg[])
{
FileInputStream fis=null;
FileOutputStream fos=null;
try
{
fis=new FileInputStream("d:/mypackage1/Start.class");
fos=new FileOutputStream("d:/mypackage1/Start.java");
int c;
while((c=fis.read())!=-1)
fos.write(c);
}catch(Exception e)
{
System.out.println(e.getMessage());
}
finally
{
try{
if(fis!=null) fis.close();
if(fos!=null) fos.close();
}catch(IOException io)
{
System.out.println(io);
}

}
}
}