import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
class psp
{
public static void main(String gg[]) throws IOException
{
File f=new File("d:/mypackage1/FileReadWrite.txt");
f.createNewFile();
FileWriter w=new FileWriter(f);
w.write("Welcome to yash technology");
w.close();
FileReader r=new FileReader(f);
char a[]=new char[100];
r.read(a);
for(char c:a) System.out.print(c);
//f.close();
}
}