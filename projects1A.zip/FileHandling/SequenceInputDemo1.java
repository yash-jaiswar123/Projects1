import java.io.FileInputStream;
import java.io.IOException;
import java.io.SequenceInputStream;
class psp
{
public static void main(String gg[]) throws IOException
{
FileInputStream f1=new FileInputStream("d:/mypackage1/xyz");
FileInputStream f2=new FileInputStream("d:/mypackage1/jj");
SequenceInputStream st=new SequenceInputStream(f1,f2);
int i;
while((i=st.read())!=-1)
{
System.out.print((char)i);
}
st.close();
f1.close();
f2.close();
}
}