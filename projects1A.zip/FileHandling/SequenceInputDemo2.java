import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.SequenceInputStream;
import java.io.File;
class psp
{
public static void main(String gg[]) throws IOException
{
FileInputStream f1=new FileInputStream("d:/mypackage1/xyz");
FileInputStream f2=new FileInputStream("d:/mypackage1/jj");
File f3=new File("d:/mypackage1/combine.txt");
f3.createNewFile();
FileOutputStream f4=new FileOutputStream(f3);
SequenceInputStream st=new SequenceInputStream(f1,f2);
int i;
while((i=st.read())!=-1)
{
f4.write(i);
}
st.close();
f1.close();
f2.close();
f4.close();
}
}