import java.io.BufferedInputStream;
import java.io.IOException;
//import java.io.BufferedOutputStream;
import java.io.FileInputStream;
class psp
{
public static void main(String gg[])
{
try
{
FileInputStream fin=new FileInputStream("d:/mypackage1/xyz");
BufferedInputStream binput=new BufferedInputStream(fin);
int i;
while((i=binput.read())!=-1) System.out.print((char)i);
binput.close();
fin.close();
}catch(Exception e)
{
e.printStackTrace();
}

}
}