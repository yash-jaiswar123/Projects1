import java.io.File;
import java.io.IOException;
class psp
{
public static void main(String gg[]) throws IOException
{
File f=new File("d:/mypackage1/xyz");
f.createNewFile();//create new file in mypackage folder named as xyz
System.out.println(f.exists());
System.out.println(f.getName());
System.out.println(f.length());
System.out.println(f.canWrite());
f.delete();
}
}