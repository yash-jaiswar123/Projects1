import java.io.File;
class psp
{
public static void main(String gg[]) 
{
File f=new File("d:/mypackage1/Start.java");
System.out.println(f.exists());
System.out.println(f.getName());
System.out.println(f.length());
System.out.println(f.canWrite());
}
}