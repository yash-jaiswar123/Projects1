import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
class psp
{
public static void main(String gg[]) throws IOException
{
FileInputStream fis=new FileInputStream("d:/mypackage1/xyz");
FileOutputStream fos=new FileOutputStream("d:/mypackage1/jj");//if file not present then it create new file
int c;
while((c=fis.read())!=-1)
{
fos.write(c);//it delete whole data of file and start writing from 1st byte
System.out.println(c);//it print ascii code just typecasting it into char
}
fis.close();
fos.close();
}
}
/*by creating object of file output stream just pass second argument as true so file open on append mode
*/