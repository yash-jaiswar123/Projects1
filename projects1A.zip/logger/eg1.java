import java.util.logging.*;
class psp
{
public static void main(String gg[])
{
Logger logger=Logger.getLogger(psp.class.getName());
logger.info("Message 1");
logger.info("Message 2");
}
}
//Architecture of java logging platform
//different logging level
//formatters ,logging anf performance
//logger class