import DTOFolder.*;
import java.sql.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.Console;
import java.util.Scanner;
import ExceptionHandle.*;
class BankingOperation
{
static BufferedReader br;
static 
{
br=new BufferedReader(new InputStreamReader(System.in));
}
public static void EmployeeValidation()
{
String userName;
String password;
try{
int eCheck=0;
Console con=System.console();
System.out.print("Enter the username :");
userName=br.readLine();
System.out.print("Enter the password :");
password=String.valueOf(con.readPassword());
Connection c=DTOConnection.getConnection();
PreparedStatement ps=c.prepareStatement("select password from Employee where username=?");
ps.setString(1,userName);
ResultSet rs=ps.executeQuery();
if(!rs.next()) eCheck++;
ps=c.prepareStatement("select username from Employee where password=?");
ps.setString(1,password);
rs=ps.executeQuery();
if(!rs.next()) eCheck++;
if(eCheck!=0)
{
 System.out.println("Invalid username or password");
 return;
}
c.close();
EmployeeOperation eo=new EmployeeOperation();
int ch=5;
while(true)
{
System.out.println("-------------Employee Menu----------------");
System.out.println("1.) Check Customers");
System.out.println("2.) Add new Customers");
System.out.println("3.) Check Customer Balance");
System.out.println("4.) Check Customer Account Details");
System.out.println("5.) Confirm and add new Customer");
System.out.println("6.) Logout");
try
{
System.out.print("Enter the choice :");
ch=Integer.parseInt(br.readLine());
}catch(Exception e)
{
throw new BankingException("Please Enter the valid input");
}
if(ch==1) eo.checkCustomers();
if(ch==2) eo.addNewCustomer(); 
if(ch==3) eo.checkBankBalance();
if(ch==4) eo.checkCustomerAccountDetails();
if(ch==5) eo.confirmCustomer();
if(ch==6) return;
}
}catch(Exception e)
{
System.out.println(e);
}
}
public static void existingCustomerValidation()
{
Console con=System.console();
int accountNum,eCheck=0;
String password,cPassword;
try{
System.out.print("Enter the Account number :");
accountNum=Integer.parseInt(br.readLine());
System.out.print("Enter the Password :");
password=String.valueOf(con.readPassword());
cPassword=password;
Connection c=DTOConnection.getConnection();
PreparedStatement ps=c.prepareStatement("select * from Customer where accountNum=?");
ps.setInt(1,accountNum);
ResultSet rs=ps.executeQuery();
if(!rs.next()) eCheck++;
ps=c.prepareStatement("select * from Customer where password=?");
ps.setString(1,password);
rs=ps.executeQuery();
if(!rs.next()) eCheck++;
if(eCheck!=0)
{
System.out.println("Invalid username or password");
return;
}
password=rs.getString("password");

if(password.equals("admin"))
{
System.out.print("Please Enter the new password :");
password=br.readLine();
ps=c.prepareStatement("update Customer set password=? where AccountNum=?");
ps.setString(1,password);
ps.setInt(2,accountNum);
ps.executeUpdate();
return;
}
c.close();
int ch=3;
while(true)
{
System.out.println("1.) Send Money :");
System.out.println("2.) Check Bank Balance :");
System.out.println("3.) Logout");
System.out.print("Enter the choice :");
ch=Integer.parseInt(br.readLine());
System.out.println("-------------------------------------------");
if(ch==1) CustomerOperation.sendMoney(accountNum);
if(ch==2) CustomerOperation.checkBalance(accountNum);
if(ch==3) return;
}
}catch(Exception e)
{
System.out.println(e);
}
}
public static void newCustomerAdd()
{
String name;
String gender;
int age;
try{
Connection c=DTOConnection.getConnection();
System.out.print("Enter the name :");
name=br.readLine();
System.out.print("Enter the Gender :");
gender=br.readLine();
System.out.print("Enter the Age :");
age=Integer.parseInt(br.readLine());
PreparedStatement ps=c.prepareStatement("insert into NewCustomer(Name,Gender,Age) values (?,?,?)",Statement.RETURN_GENERATED_KEYS);
ps.setString(1,name);
ps.setString(2,gender);
ps.setInt(3,age);
ps.executeUpdate();
ResultSet rs=ps.getGeneratedKeys();
if(rs.next())
System.out.println("Your Applocation Id is :"+rs.getInt(1));
}catch(Exception e)
{
System.out.println(e);
}
}
public static void main(String gg[])
{
int ch=4;
Scanner sc=new Scanner(System.in);
while(true)
{
System.out.println("1.) Bank Employee");
System.out.println("2.) Customer Login");
System.out.println("3.) New Customer want to open Account");
System.out.println("4.) Logout");
try
{
System.out.print("Enter the choice :");
ch=sc.nextInt();
}catch(Exception e)
{
System.out.println("Please give valid input between(1-4)");
}
System.out.println("--------------------------------------");
if(ch==1)
{
EmployeeValidation();
}
if(ch==2)
{
existingCustomerValidation();
}
if(ch==3)
{
newCustomerAdd();
}
if(ch==4) break;
}
}
}