import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import DTOFolder.*;
public class CustomerOperation
{
static private BufferedReader br;
static 
{
br=new BufferedReader(new InputStreamReader(System.in));
}
public static void sendMoney(int accountNum)
{
try{
int sendAccountNum;
float amount,balance;
System.out.print("Enter the Account num to send money :");
sendAccountNum=Integer.parseInt(br.readLine());
System.out.println("Enter the amount to send :");
amount=Float.parseFloat(br.readLine());
Connection c=DTOConnection.getConnection();
PreparedStatement ps;
ResultSet rs;
System.out.print("Enter the password :");
String password=br.readLine();
ps=c.prepareStatement("select balance from Customer where password=?");
ps.setString(1,password);
rs=ps.executeQuery();
if(!rs.next())
{
System.out.println("Invalid password");
return;
}
balance=rs.getFloat(1);
if(amount>balance)
{
System.out.println("Unable to do transaction because your current balance is :"+balance);
return;
}
amount=balance-amount;
ps=c.prepareStatement("update Customer set balance=? where AccountNum=?");
ps.setFloat(1,amount);
ps.setInt(2,accountNum);
ps.executeUpdate();
System.out.println("Transaction Successful");
System.out.println("Your Current balance is :"+amount);
c.close();
}catch(Exception e)
{
System.out.println(e);
}
}
public static void checkBalance(int accountNum)
{
try{
Connection c=DTOConnection.getConnection();
System.out.print("Enter the password :");
String password=br.readLine();
PreparedStatement ps=c.prepareStatement("select balance from Customer where password=?");
ps.setString(1,password);
ResultSet rs=ps.executeQuery();
if(!rs.next())
{
System.out.println("Invalid password");
return;
}
System.out.println("Your Current balance is :"+rs.getFloat(1));

}catch(Exception e)
{
System.out.println(e);
}
}
}