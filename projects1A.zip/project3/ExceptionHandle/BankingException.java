package ExceptionHandle;

public class BankingException extends RuntimeException{
	public BankingException(String exception)
	{
	System.out.println(exception);
	}

}
