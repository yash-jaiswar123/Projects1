package DTOFolder;
import java.sql.Connection;
import java.sql.DriverManager;
public class DTOConnection
{
public static Connection getConnection()
{
 Connection c=null;
 try{
  Class.forName("com.mysql.cj.jdbc.Driver");
  String url="jdbc:mysql://localhost:3306/yash";
  String user="root";
  String pass="root";
  c=DriverManager.getConnection(url,user,pass);
 }catch(Exception e)
  {
  e.printStackTrace();
  }
  return c;
}
}
