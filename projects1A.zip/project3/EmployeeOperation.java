import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import DTOFolder.*;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
public class EmployeeOperation
{
private BufferedReader br;
public EmployeeOperation()
{
br=new BufferedReader(new InputStreamReader(System.in));
}
/*public void addDate() throws Exception
{
String date="10";
String month="08";
String year="2000";
LocalDate d=new LocalDate(10,08,2000);
System.out.println(d);
}
*/
public void checkCustomers()
{
try{
Connection c=DTOConnection.getConnection();
PreparedStatement ps=c.prepareStatement("select Name,Gender,Balance from Customer");
ResultSet rs=ps.executeQuery();
int id=1;
System.out.println("--------------Customers list-----------");
while(rs.next())
{
System.out.printf("%5d %5s %5s %5f\n",id,rs.getString("Name"),rs.getString("Gender"),rs.getFloat("Balance"));
id++;
}
if(id==1)
{
System.out.println("Not yet any customer added");
return;
}
c.close();
}catch(Exception e)
{
System.out.println(e);
}
}

public void checkCustomerAccountDetails()
{
int accountNum;
try{
System.out.println("Enter Account Number of Customer :");
accountNum=Integer.parseInt(br.readLine());
Connection c=DTOConnection.getConnection();
PreparedStatement ps=c.prepareStatement("select Name,Gender,Balance from Customer where AccountNum=?");
ps.setInt(1,accountNum);
ResultSet rs=ps.executeQuery();
if(!rs.next())
{
System.out.println("Invalid Account Num");
return;
}
System.out.println("Name :"+rs.getString("Name"));
System.out.println("Gender :"+rs.getString("Gender"));
System.out.println("Balance :"+rs.getFloat("Balance"));
}catch(Exception e)
{
System.out.println(e);
}
}
public void addNewCustomer()
{
String name,gender;
int age;
float balance;
try{
System.out.println("Enter the Name of Customer :");
name=br.readLine();
System.out.println("Enter the Age :");
age=Integer.parseInt(br.readLine());
System.out.println("Enter the Gender :");
gender=br.readLine();
System.out.println("Enter the Balance :");
balance=Float.parseFloat(br.readLine());
Connection c=DTOConnection.getConnection();
PreparedStatement ps=c.prepareStatement("insert into Customer (Name,Gender,Balance,age) values (?,?,?,?)",Statement.RETURN_GENERATED_KEYS);
ps.setString(1,name);
ps.setString(2,gender);
ps.setFloat(3,balance);
ps.setInt(4,age);
ps.executeUpdate();
ResultSet rs=ps.getGeneratedKeys();
System.out.println("Customer added :");
if(rs.next())
System.out.println("Your Account num is :"+rs.getInt(1));
c.close();
}catch(Exception e)
{
System.out.println(e);
}
}
public void checkBankBalance()
{
try{
int accountNum;
System.out.print("Enter the Account Num :");
accountNum=Integer.parseInt(br.readLine());
Connection c=DTOConnection.getConnection();
PreparedStatement ps=c.prepareStatement("select Balance from Customer where AccountNum=?");
ps.setInt(1,accountNum);
ResultSet rs=ps.executeQuery();
if(rs.next())
System.out.println("Balance :"+rs.getFloat(1));
else 
System.out.println("Invalid Account number");
}catch(Exception e)
{
System.out.println(e);
}
}
public void deleteCustomer(Connection c,int id) throws Exception
{
PreparedStatement ps=c.prepareStatement("delete from NewCustomer where id=?");
ps.setInt(1,id);
ps.executeUpdate();
}
public void confirmCustomer()
{
try{
Connection c=DTOConnection.getConnection();
PreparedStatement ps=c.prepareStatement("select  * from NewCustomer limit 1");
ResultSet rs=ps.executeQuery();
String name,gender;
int id,age;
if(rs.next())
{
name=rs.getString("Name");
gender=rs.getString("Gender");
id=rs.getInt("id");
age=rs.getInt("Age");
}
else
{
System.out.println("Not any Customer apply");
return;
}
System.out.println("---------------confirm Customer------------");
System.out.println("Name  :"+name);
System.out.println("Gender :"+gender);
System.out.println("Age :"+age);
System.out.println("------------------------------------");
System.out.println("Do you want to confirm the Customer (yes/no):");
String flag=br.readLine();
if(!flag.equalsIgnoreCase("yes"))
{
System.out.println("Customer not added");
deleteCustomer(c,id);
return;
}
System.out.print("Enter the balance of Customer :");
float balance=Float.parseFloat(br.readLine());
ps=c.prepareStatement("insert into Customer (Name,Gender,age,balance) values(?,?,?,?)",Statement.RETURN_GENERATED_KEYS);
ps.setString(1,name);
ps.setString(2,gender);
ps.setInt(3,age);
ps.setFloat(4,balance);
ps.executeUpdate();
rs=ps.getGeneratedKeys();
if(rs.next())
{
deleteCustomer(c,id);
System.out.println("Customer added");
System.out.println("Your account Num is :"+rs.getInt(1));
return;
}
else System.out.println("Customer not Added");
c.close();
}catch(Exception e)
{
System.out.println(e);
}
}
}