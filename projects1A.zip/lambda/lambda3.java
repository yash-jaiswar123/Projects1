import java.util.Map;
import java.util.HashMap;
import java.util.List;
import java.util.LinkedList;
import java.util.Collections;
import java.util.Iterator;
class psp
{
public static void main(String gg[])
{
Map<Integer,String>map=new HashMap<>();
map.put(1,"abc");
map.put(2,"xyz");
map.put(3,"jkl");
map.put(4,"kmo");
map.put(5,"lig");
List<Map.Entry<Integer,String>> lst=new LinkedList<>(map.entrySet());
Collections.sort(lst,(i1,i2)->i1.getValue().compareTo(i2.getValue()));
Iterator iter=lst.iterator();
while(iter.hasNext())
{
Map.Entry m=(Map.Entry)iter.next();
System.out.println(m.getKey()+" "+m.getValue());
}

}
}