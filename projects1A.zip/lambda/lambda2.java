import java.util.List;
import java.util.LinkedList;
class psp
{
public static void main(String gg[])
{
List<Integer> lst=new LinkedList<>();
lst.add(1);
lst.add(1);
lst.add(1);
lst.add(1);
lst.add(1);
lst.forEach((n)->System.out.println(n));
}
}