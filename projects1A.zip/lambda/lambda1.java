interface A
{
public int add(int a,int b);
}

class psp
{
public static void main(String gg[])
{
A a=(x,y)->{
System.out.print("Add is :");
return x+y;
};
System.out.println(a.add(5,7));

}
}