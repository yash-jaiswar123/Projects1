public class Account
{
private int AccountNumber;
private float balance;
Account()
{
this.AccountNumber=0;
this.balance=0.0f;
}
public void setAccountNumber(int AccountNumber)
{
this.AccountNumber=AccountNumber;
}
public int getAccountNumber()
{
return this.AccountNumber;
}
public void setBalance(float balance)
{
this.balance=balance;
}
public float getBalance()
{
return this.balance;
}
}