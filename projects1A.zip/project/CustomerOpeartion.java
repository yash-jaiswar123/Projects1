import java.io.*;
public class CustomerOperation
{
public static void sendMoney(Customer customer)
{
try
{
BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
int destinationAccountNum;
float amount;
System.out.print("Enter the account number to send money :");
destinationAccountNum=Integer.parseInt(br.readLine());
System.out.print("Enter the Amount to send :");
amount=Float.parseFloat(br.readLine());
}catch(IOException e)
{
System.out.println(e);
}
}
}