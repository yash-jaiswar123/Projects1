public class Customer
{
private String name;
private int age;
private char gender;
private Account account;
private String password;
Customer()
{
this.name="";
this.account=null;
this.age=0;
this.gender=' ';
this.password="customer";
}
public void setPassword(String password)
{
this.password=password;
}
public String getPassword()
{
return this.password;
}
public void setName(String name)
{
this.name=name;
}
public String getName()
{
return this.name;
}
public void setAccount(Account account)
{
this.account=account;
}
public Account getAccount()
{
return this.account;
}
public int getAccountNum()
{
return this.getAccount().getAccountNumber();
}
public void setAge(int age)
{
this.age=age;
}
public int getAge()
{
return this.age;
}
public void setGender(char gender)
{
this.gender=gender;
}
public char getGender()
{
return this.gender;
}
}

