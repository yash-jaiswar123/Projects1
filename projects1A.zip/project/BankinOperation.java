import java.util.Scanner;
import java.io.*;
class ListCollection
{
public static Customer collection[]=new Customer[10];
public static void add(Customer []lst,int size)
{
for(int i=0;i<size;i++)
collection[i]=lst[i];
}
public static Customer[] getCollection()
{
return collection;
}
}
class CustomerList
{
private static Customer customerList[];
private static int size=0;
private static int accountNum=1000;
CustomerList()
{
customerList=new Customer[10];
}
public static void addCustomer()
{
try
{
BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
Customer customer=new Customer(); 
System.out.println("------Customer Add Form--------------");
System.out.print("Enter the Name of Customer:");
customer.setName(br.readLine());
System.out.print("Enter the age of Customer:");
customer.setAge(Integer.parseInt(br.readLine()));
System.out.print("Enter the gender of Customer:");
customer.setGender(br.readLine().charAt(0));
accountNum++;
Account account=new Account();
account.setAccountNumber(accountNum);
System.out.print("Enter the Balance of Customer:");
account.setBalance(Float.parseFloat(br.readLine()));
customer.setAccount(account);
customerList[size]=customer;
size++;
System.out.println("--------------------------------------");
System.out.println("Customer Added Account Number is :"+accountNum);
ListCollection.add(customerList,size);
System.out.println("--------------------------------------");
}catch(Exception e)
{
System.out.println(e);
}
}
public static Customer getDetails()
{
Scanner sc=new Scanner(System.in);
int accountNumber;
System.out.print("Enter the Account Number of Customer :");
accountNumber=sc.nextInt();
Customer a;
Customer list[]=ListCollection.getCollection();
for(int i=0;i<size;i++)
{
a=list[i];
if(a.getAccount().getAccountNumber()==accountNumber)
{
return a;
}
}
return null;
}
public static Customer []getList()
{
return customerList;
}
public static int totalCustomer()
{
return size;
}
}

class EmployeeOperation
{
private static CustomerList customerList=new CustomerList();
public void checkCustomers()
{
Customer customer[]=customerList.getList();
int size=customerList.totalCustomer();
if(size==0) 
{
System.out.println("Not yet any customer added");
return;
}
System.out.println("----------Customers List--------------");
System.out.println("S.No.   Customer Name");
System.out.println("--------------------------------------");
for(int i=0;i<size;i++) 
System.out.println((i+1)+"       "+customer[i].getName());
System.out.println("---------------------------------------");
}
public void addNewCustomer()
{
customerList.addCustomer();
}

public void checkBankBalance()
{
try
{
BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
System.out.print("Enter the Account Number :");
int accountNum=Integer.parseInt(br.readLine());
Customer customer[]=CustomerList.getList();
int size=CustomerList.totalCustomer();
Customer a=null;
Customer data=null;
for(int i=0;i<size;i++)
{
a=customer[i];
if(accountNum==a.getAccount().getAccountNumber())
{
data=a;
break;
}
}
if(data==null) 
{
System.out.println("Invalid Account number ");
return;
}
System.out.println("Total Balance in Account Num :"+accountNum+" is :"+data.getAccount().getBalance());
return;
}catch(IOException ioe)
{
System.out.println(ioe);
}

}
public void checkCustomerAccountDetails()
{
Customer c=customerList.getDetails();
if(c==null)
{
System.out.println("Invalid Account Number :");
return;
}
System.out.println("---------Customer Details----------------");
System.out.println("Account Holder Name :"+c.getName());
System.out.println("Account Holder Gender :"+c.getGender());
System.out.println("Account Holder Age :"+c.getAge());
System.out.println("-------------------------------------------");
}
}

class BankingOperation
{
static Scanner sc;
BankingOperation()
{
sc=new Scanner(System.in);
}
public static void validation()
{
String password;
System.out.print("Enter the password :");
sc.nextLine();
password=sc.nextLine();
if(!password.equals("abc@123"))
{
System.out.println("Invalid password");
return;
}
System.out.println("--------------Welcome-------------------");
EmployeeOperation eo=new EmployeeOperation();
int ch;
while(true)
{
System.out.println("-------------Employee Menu----------------");
System.out.println("1.) Check Customers");
System.out.println("2.) Add new Customers");
System.out.println("3.) Check Customer Balance");
System.out.println("4.) Check Customer Account Details");
System.out.println("5.) Logout");
System.out.print("Enter the choice :");
ch=sc.nextInt();
if(ch==1) eo.checkCustomers();
if(ch==2) eo.addNewCustomer(); 
if(ch==3) eo.checkBankBalance();
if(ch==4) eo.checkCustomerAccountDetails();
if(ch==5) return;
}
}
public static void existingCustomerValidation()
{
Console con=System.console();
int accountNum;
try
{
CustomerList cl=new CustomerList();
System.out.println(cl.totalCustomer());
Customer customer=cl.getDetails();
System.out.println(customer);
if(customer==null)
{
System.out.println("Invalid password");
return;
}
if(customer.getPassword().equals("customer"))
{
System.out.print("Enter the new Password :");
customer.setPassword(String.valueOf(con.readPassword()));
return;
}
System.out.print("Enter the password :");
String password=String.valueOf(con.readPassword());
if(!customer.getPassword().equals(password))
{
System.out.println("Invalid password :");
return;
}
BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
int ch;
while(true)
{
System.out.println("1.) Send Money :");
System.out.println("2.) Check Bank Balance :");
System.out.println("3.) Logout");
System.out.print("Enter the choice :");
ch=Integer.parseInt(br.readLine());
System.out.println("-------------------------------------------");
if(ch==1) CustomerOperation.sendMoney(customer);
if(ch==2) CustomerOperation.checkBalance(customer);
if(ch==3) return;
}
}catch(IOException io)
{
System.out.println(io);
}
}
public static void newCustomerDetails()
{
//code to be added
EmployeeOperation eo=new EmployeeOperation();
eo.addNewCustomer();
}
public static void main(String gg[])
{
int ch;
BankingOperation br=new BankingOperation();
while(true)
{
System.out.println("1.) Bank Employee");
System.out.println("2.) Customer Login");
System.out.println("3.) New Customer want to open Account");
System.out.println("4.) Logout");
System.out.print("Enter the choice :");
ch=sc.nextInt();
System.out.println("--------------------------------------");
if(ch==1)
{
validation();
}
if(ch==2)
{
existingCustomerValidation();
}
if(ch==3)
{
newCustomerDetails();
}
if(ch==4) break;

}
}
}