static class Outer
{
static class Inner
{
void show()
{
System.out.println("Show called ");
}
}
}
public class InnerClass3
{
public static void main(String gg[])
{
//Outer.Inner in=new Outer.Inner();
//in.show();
}
}