class A
{
A()
{
System.out.println("A class constructor");
}
}
class SuperDemo extends A
{
SuperDemo()
{
//super() written by compiler
System.out.println("Super Demo constructor");
}
public static void main(String gg[])
{
SuperDemo d=new SuperDemo();
}
}