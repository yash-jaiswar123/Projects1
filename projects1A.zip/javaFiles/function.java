class A
{
int ab=100;
public void check()
{
System.out.println("A Called");
}
public int check(int a)
{
System.out.println("B called");
return a;
}
}
class psp
{
public static void main(String gg[])
{
A a=new A();
int b=a.check(5);
//System.out.println(a.ab);
}
}