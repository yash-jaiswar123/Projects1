class psp
{
public static void main(String gg[])
{
Object obj=new Object();
String s=new String("5");
s=(String)obj;
}
}