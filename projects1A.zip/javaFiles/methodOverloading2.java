class A
{
void show(Object a)
{
System.out.println("object method");
}
void show(String a)
{
System.out.println("string method");
}

public static void main(String gg[])
{
A a=new A();
a.show('c');//print object method
a.show("yash"); //print string method
}
}