interface check
{
public void show();
default void detect()
{
System.out.println("aaa");
}
static void display()
{
System.out.println("display");
}
}