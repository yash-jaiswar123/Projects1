interface A
{
public void show();
public void display();
}
class psp
{
public static void main(String gg[])
{
A a=new A(){
public void show()
{
System.out.println("Show called");
}
public void display()
{
System.out.println("Display called");
}
};
a.show();
System.out.println("called");
a.display();
}
}