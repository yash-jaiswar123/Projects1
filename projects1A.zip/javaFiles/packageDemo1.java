class packageDemo
{
public static void main(String gg[])
{
mypackage.Start obj=new mypackage.Start();
obj.display();  
}
}