class check
{
private int num;
private void toCheck()
{
System.out.println("Check method");
}
}

class psp
{
public static void main(String gg[])
{
check c=new check();
c.toCheck();
c.num=10;
System.out.println(c.num);
}
}
//private variable and method can access  in same class using main method also