class DemoWithThis
{
int i;
public void setNum(int i)
{
this.i=i;
}
public void show()
{
System.out.println(this.i);
}
}

class Demo
{
public static void main(String gg[])
{
DemoWithThis t=new DemoWithThis();
t.setNum(15);
t.show();
}
}