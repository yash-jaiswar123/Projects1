class enumAssignment
{
enum Days
{
Monday(1),Tuesday(2),Wednesday(3),Thursday(4),Friday(5),Saturday(6),Sunday(7);
int val;
Days(int i)
{
this.val=i;
}
}
public static void main(String gg[])
{
Days d=Days.Monday;
switch(d)
{
case Monday:
System.out.println(d.ordinal());
System.out.println(d.val);
break;
case Tuesday:
System.out.println(d.ordinal());
System.out.println(d.val);
break;
case Wednesday:
System.out.println(d.ordinal());
System.out.println(d.val);
break;
case Thursday:
System.out.println(d.ordinal());
System.out.println(d.val);
break;
case Friday:
System.out.println(d.ordinal());
System.out.println(d.val);
break;
case Saturday:
System.out.println(d.ordinal());
System.out.println(d.val);
break;
case Sunday:
System.out.println(d.ordinal());
System.out.println(d.val);
break;
}

}
}