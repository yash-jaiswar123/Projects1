class A
{
void display()
{
System.out.println("Display");
}
}
class SuperDemo extends A
{
void display()
{
System.out.println("Derived display");
}
void show()
{
display();
super.display();
}
public static void main(String gg[])
{
SuperDemo d=new SuperDemo();
d.show();
}
}