class psp
{
psp()	
{
System.out.println("No argument constructor");
}
psp(int n)
{
this();
System.out.println("Parameterized constructor");
}
public void show()
{
//this();
}

public static void main(String gg[])
{
psp p=new psp(10);
}
}