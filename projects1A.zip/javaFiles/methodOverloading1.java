class psp
{
final void show(int a)
{
System.out.println("int parameter");
}
final void show(String a)
{
System.out.println("string parameter");
}


public static void main(String gg[])
{
psp p=new psp();
p.show(10);
p.show("yash");
}
}