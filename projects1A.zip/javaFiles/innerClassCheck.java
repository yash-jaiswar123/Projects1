class Outer
{
static private int a=10;
static private void show()
{
System.out.println("show");
}
class Inner
{
public void display()
{
show();
System.out.println(a);
}
}
}
class psp
{
public static void main(String gg[])
{
Outer o=new Outer();
Outer.Inner i=o.new Inner();
i.display();
}
}