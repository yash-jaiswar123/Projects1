class c1
{
c1(c2 c)
{
System.out.println("c1 class constructor called");
}
}

class c2
{
void show()
{
c1 c=new c1(this);
}
public static void main(String gg[])
{
c2 c=new c2();
c.show();
}
}