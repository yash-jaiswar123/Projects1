class A
{

}
class B extends A
{

}
class C extends B
{

}

class D extends B
{

}

//a->b->c,d