class Outer
{
class Inner
{
void show()
{
System.out.println("Show called ");
}
}
}
public class InnerClass1
{
public static void main(String gg[])
{
Outer o=new Outer();
// o.show(); error cannot find symbol
Outer.Inner in=o.new Inner();
in.show();
}
}