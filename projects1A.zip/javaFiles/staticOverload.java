class A
{
public static void check()
{
System.out.println("No argument check");
}
public static void check(int a)
{
System.out.println("in argument check");
}
}
class psp
{
public static void main(String gg[])
{
A a=new A();
a.check();
}
}