class psp
{
void y1(psp p)
{
System.out.println("Y1 method");
}
void y2()
{
y1(this);
}
public static void main(String gg[])
{
psp p=new psp();
p.y2();
}
}