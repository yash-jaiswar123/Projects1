//extract number from a string
import java.util.regex.*;
class psp
{
public static void main(String gg[])
{
Pattern p=Pattern.compile("\\d+");
Matcher m=p.matcher("3535yash@123");
while(m.find()) System.out.println(m.group());
}
}