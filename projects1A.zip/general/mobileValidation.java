import java.util.regex.*;
class psp
{
public static void main(String gg[])
{
Pattern p=Pattern.compile("[0-9]{10}");
Matcher m=p.matcher(gg[0]);
if(m.find())
System.out.println("Valid");
else System.out.println("Invalid");
}
}