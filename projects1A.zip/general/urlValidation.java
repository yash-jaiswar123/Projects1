import java.util.regex.*;
class psp
{
public static void main(String gg[])
{
Pattern p=Pattern.compile("https:");
Matcher m=p.matcher("https://you.yash.com");
if(m.find())
{
if(m.start()==0 && m.end()==6)
System.out.println("valid");
else System.out.println("Invalid");
}
else
{
System.out.println("Invalid");
}
}
}