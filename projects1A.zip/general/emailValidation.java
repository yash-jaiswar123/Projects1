import java.util.regex.*;
class psps
{
public static void main(String gg[])
{
Pattern p=Pattern.compile("[a-zA-Z0-9]+@[g]+[m]+[a]+[i]+[l]+\\.[c]+[o]+[m]]");

Matcher m=p.matcher(gg[0]);
System.out.println(m.find());
if(m.find())
{
System.out.println("Valid");
}
else System.out.println("Invalid");
}
}