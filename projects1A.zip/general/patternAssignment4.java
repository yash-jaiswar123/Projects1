import java.util.regex.Pattern;
import java.util.regex.Matcher;
class psp
{
public static void main(String gg[])
{
Pattern pattern=Pattern.compile(gg[0]);
Matcher m=pattern.matcher(gg[1]);
if(m.find())
{
System.out.println("found start index :"+m.start()+", end index :"+m.end());
}
else System.out.println("Not found");
}
}