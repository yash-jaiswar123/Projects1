import java.util.regex.*;
class psp
{
public static void main(String gg[])
{
/*Pattern p=Pattern.compile("[0-9]{2}+[.-/]+[0-9]{2}+[.-/]+[0-9]{4}");*/
Pattern p=Pattern.compile("^[0-3]?[0-9]+[.-/]+[0-3]?[0-9]+[.-/]+(?:[0-9]{2})?[0-9]{2}$");
Matcher m=p.matcher(gg[0]);
if(m.find())System.out.println("valid");
else System.out.println("Invalid");
}
}
//regex for date validation
//"^[0-3]?[0-9]/[0-3]?[0-9]/(?:[0-9]{2})?[0-9]{2}$"