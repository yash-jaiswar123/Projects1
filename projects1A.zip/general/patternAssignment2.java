import java.util.regex.*;
class psp
{
public static void main(String gg[])
{
Pattern pattern=Pattern.compile("\\R");
String s[]=pattern.split("yash\njaiswar\nWelcome");
System.out.println(s[0]);
}
}