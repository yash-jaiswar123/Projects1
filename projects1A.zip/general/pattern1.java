import java.util.regex.Pattern;
import java.util.regex.Matcher;
class psp
{
public static void main(String gg[])
{
Pattern pattern=Pattern.compile(gg[0]);
Matcher matcher=pattern.matcher(gg[1]);
//It check gg[0] exists in gg[1];
if(matcher.find())
{
System.out.println("found");
}
else System.out.println("Not found");

}
}