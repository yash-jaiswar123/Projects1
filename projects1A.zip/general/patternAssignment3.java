import java.util.regex.*;
class psp
{
public static void main(String gg[])
{
int n=Integer.parseInt(gg[0]);
System.out.println(new String(new char[n]).matches(".?|(..+?)\\1+"));

}
}