function show(msg)
{
console.log(msg);
}
let mypromise=new Promise(function(resolve,reject){
let x=testUserName("yash510@gmail.com","abc@123");
if(x==1)
resolve("Your welcome");
else if(x==2)
resolve("Invalid Username did not match with password");
else if(x==0)
reject("username did not matched with password"); 
});
mypromise.then(function(value){show(value);},function(error){show(error);});

function testUserName( uname, pass)
{
if(uname=="yash510@gmail.com" && pass=="abc@123")
return 1;

if(uname=="yash510@gmail.com" && pass!="abc@123")
return 0;

if(uname!="yash510@gmail.com" || pass!="abc@123")
return 2;

}