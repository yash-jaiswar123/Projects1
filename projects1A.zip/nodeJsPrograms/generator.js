function * gen()
{
yield 5;
yield 10;
yield 15;
}
var x=gen();
var p=x.next().value;
console.log("First value which is generated :-"+p);
for(let i=1;i<=p;i+=2)
console.log(i);
console.log("second value which is generated :-"+x.next().value);
console.log("third value which is generated :-"+x.next().value);
