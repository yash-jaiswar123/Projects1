class A
{
a1()
{
console.log("a1");
}
}
class B extends A
{
a2()
{
console.log("a2");
}
}
let b=new B();
b.a1();
b.a2();
