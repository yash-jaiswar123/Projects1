var t={"name":"akash","age":21,"salary":2345,"dob":"10/08/2001"};

var e=({name,age,salary,dob})=>{
console.log(name);
console.log(age);
console.log(salary);
console.log(dob);	
}

e(t);