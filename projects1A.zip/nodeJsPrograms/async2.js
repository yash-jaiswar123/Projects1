setTimeout(fun1,10000);
function fun1()
{
console.log("Hello after 5 seconds");
}
fun1();
/*for(let i=1>i<=100;i++)
{

}*/