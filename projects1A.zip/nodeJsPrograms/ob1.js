var name="sunil";
var dob="23/02/2000";
var sal=23456;

var e={name,dob,sal};
console.log(e);

var fn=function(){
console.log("function 1");
}
var d={name,dob,sal,fn};
d.fn();