setInterval(fun1,1000);
setInterval(fun2,500);
function fun1(){
console.log("Invoke after 1000 ");
}
function fun2()
{
console.log("Invoke after 500");
}
fun1();
fun2();