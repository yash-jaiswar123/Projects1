const marks=new Map([["anil",67],["mohan",78],["sunil",70]]);
console.log(marks.get("anil"));

marks.set("sanjay",77);
marks.set("sumit",87);
marks.set("jay",70);
marks.set("vijay",78);

marks.forEach(function(value,key){
console.log("Key :"+key+","+"Value :"+value);
});
marks.delete("anil");
console.log("--------------");
marks.forEach(function(value,key){
console.log("Key :"+key+","+"Value :"+value);
});

if(marks.has("sanjay"))
  console.log("Sanjay  exists");

for(let t of marks.entries())
console.log(t[0]+" "+t[1]);//t is an array