var carnames=["Maruti suzuki","Volvo","BMW","Mercedes"];
var[car1,car2,car3,car4]=carnames;
console.log(car1);
console.log(car2);
console.log(car3);
console.log(car4);