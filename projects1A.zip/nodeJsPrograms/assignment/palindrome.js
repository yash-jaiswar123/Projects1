
function show(msg)
{
console.log(msg);
}
function checkPalindrome(str)
{
let x=0;
let y=str.length-1;
while(x<y)
{
if(str[x]!=str[y])  break;
x++;
y--;
}

if(x<y)
{
return 0;
}
else return 1;
}
let mypromise=new Promise(function(resolve,reject){
//code to check palindrome
let str="haah";
let x=checkPalindrome(str);
if(x==1)
resolve("Palindrome");
else reject("Not a palindromic string");

});

mypromise.then(function(value){show(value);},function(error){show(error);});