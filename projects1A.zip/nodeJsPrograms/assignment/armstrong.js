function show(msg)
{
console.log(msg);
}
function calculateCube(num)
{
return num*num*num;
}
function checkArmstrong(num)
{
let d=num
let sum=0;
while(d>0)
{
let digit=d%10;
d=parseInt(d/10);
sum+=calculateCube(digit);
}
if(sum==num) return 1;
else return 0;
}

var mypromise=new Promise(function(resolve,reject){
let num=152;
let x=checkArmstrong(num);
if(x==1) resolve("Armstrong number");
else reject("Not an armstrong number");
});

mypromise.then(function(value){show(value)},function(error){show(error)});