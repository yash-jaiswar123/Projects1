class Demo
{
constructor(x,y)
{
this.x=x;
this.y=y;
}
show()
{
console.log("value of x "+this.x);
console.log("Value of y "+this.y);
}
}

let d=new Demo("yash",10);
d.show();