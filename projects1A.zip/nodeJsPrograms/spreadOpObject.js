var proName={
pname:"sugar",
price:40,
qty:10,
catid:1
};
var cat={
catname:"food",
catid:6
};
var cat_pro={...proName,...cat};
console.log(cat_pro);
//second object cat property catid will replace value of first //object product
