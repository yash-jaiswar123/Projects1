var arr=[2,4,6,8];
function * gen(arrno)
{
let i=0;
while(i<arrno.length)
{
console.log("generator is called "+i+" times "+arrno[i]);
//yield arrno[i];
i++;
}
}
var y=gen(arr);
y.next();
console.log("Control back");
y.next();
y.next();
y.next();