let x=10;
{
let x=20;
console.log(x);
}
console.log(x);

var y=(x,y)=>{
return x*y;
}
console.log(y(10,20));