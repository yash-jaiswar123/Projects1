class S
{
static show()
{
console.log("statix mehtod");
}
}
S.show();
