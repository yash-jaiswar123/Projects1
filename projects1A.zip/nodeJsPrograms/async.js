function result(r)
{
console.log("result "+r);
}
function sum(a,b,callBack)
{
var s=a+b;
callBack(s);
}
sum(10,22,result);