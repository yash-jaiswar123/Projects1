const names=new Set(["anil","aman","ajay"]);
console.log(names.size);
names.add("vinit");
names.add("vikas");
names.add("vijay");
console.log(names.size);

for(let x in names.values())
console.log(names[x]);
