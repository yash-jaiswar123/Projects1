var emp2={
name:"Ajay kumar","salary":34555,"dob":"23/05/2001",printDetails(){
console.log(this.name);
console.log(this.dob);
console.log(this.salary);
}
};

emp2.printDetails();