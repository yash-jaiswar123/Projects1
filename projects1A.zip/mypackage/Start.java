package mypackage;
public class Start
{
public void display()
{
System.out.println("I amin start class display method");
}
}