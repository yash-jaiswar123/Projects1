import java.io.*;
class throwsDemo1
{
public void show() throws FileNotFoundException
{
FileInputStream f=new FileInputStream("cd.cd");
}
}
class psp
{
public static void main(String gg[])
{
throwsDemo1 t=new throwsDemo1();
try{
t.show();
}catch(FileNotFoundException fex)
{
fex.printStackTrace();
}
System.out.println("Hello-normal termination");
}
}
/*if i do not use try and catch while calling show method then compiler gives error that FileNotFoundException; must be caught or declared to be thrown
t.show();*/