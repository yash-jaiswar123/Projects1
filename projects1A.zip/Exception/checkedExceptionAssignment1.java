import java.io.FileOutputStream;
import java.io.IOException;
import java.io.FileNotFoundException;
class checkExceptionDemo
{
public static void main(String gg[]) throws FileNotFoundException,IOException
{
FileOutputStream f=new FileOutputStream("d:/mypackage1/yash");
int c=97;
f.write(c);
}
}