class UncheckedExceptionDemo
{
public static void checkException(int par)
{
try
{
int arr[]=new int[5];
String s=null;
int a=5,b=0;
String s1="yash";
Object ob1=new Object();
arr[6]=8;
s1=(String)ob1;
System.out.println(a/b);
int i=Integer.parseInt("yash");
char c=(char)4.5f;

}catch(ArithmeticException e)
{
System.out.println();
}
catch(ArrayIndexOutOfBoundsException aio)
{
System.out.println(aio);
}
catch(NullPointerException npe)
{
System.out.println(npe);
}
catch(ClassCastException ime)
{
System.out.println(ime);
}
catch(NumberFormatException nfe)
{
System.out.println(nfe);
}
}
}
class psp
{
public static void main(String gg[])
{
UncheckedExceptionDemo.checkException(5);
}
}