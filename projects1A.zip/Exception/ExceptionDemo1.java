class ExceptionDemo1
{
public static void main(String gg[])
{
System.out.println("Yash");
System.out.println(100/0);
System.out.println("Technology");
}
}