import java.io.FileInputStream;
class ExceptionDemo2
{
public static void main(String gg[])
{
try
{
FileInputStream f=new FileInputStream("abc.xyz");
}catch(Exception e)
{
System.out.println(e);
}
}
}
//Above is checked Exception means if we do not use try catch then compiler //give error(must be caught or declared to be thrown)