import java.util.Scanner;
class VoteEligibility extends Exception
{
VoteEligibility(String s)
{
super(s);
}
}
class throwDemo
{
public static void main(String gg[])
{
Scanner sc=new Scanner(System.in);
System.out.print("Enter the age :");
int age=sc.nextInt();

try{
if(age<18)
throw new VoteEligibility("Not able to ive vote");
else System.out.println("You can vote");
}catch(VoteEligibility e)
{
e.printStackTrace();
}
System.out.println("Normal termination");
}
}