package DTOFolder;
public class Employee extends Person
{
private String password;
public Employee()
{
this.password="";
}
public void setPassword(String password)
{
this.password=password;
}
public String getPassword()
{
return this.password;
}
}
