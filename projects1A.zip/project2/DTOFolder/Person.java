package DTOFolder;
public class Person
{
private String name;
private int age;
private char gender;
public Person()
{
this.name="";
this.age=0;
this.gender=' ';
}
public void setName(String name)
{
this.name=name;
}
public String getName()
{
return this.name;
}
public void setAge(int age)
{
this.age=age;
}
public int getAge()
{
return this.age;
}
public void setGender(char gender)
{
this.gender=gender;
}
public char getGender()
{
return this.gender;
}
}

