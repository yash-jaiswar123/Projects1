package DTOFolder;
public class Customer extends Person
{
private Account account;
private String password;
public Customer()
{
this.account=null;
this.password="customer";
}
public void setPassword(String password)
{
this.password=password;
}
public String getPassword()
{
return this.password;
}
public void setAccount(Account account)
{
this.account=account;
}
public Account getAccount()
{
return this.account;
}
public int getAccountNum()
{
return this.getAccount().getAccountNumber();
}
}
