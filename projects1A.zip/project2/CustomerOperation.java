import java.io.BufferedReader;
import java.io.Console;
import java.io.IOException;
import java.io.InputStreamReader;
import DTOFolder.Customer;
public class CustomerOperation
{
public static void sendMoney(Customer customer)
{
try
{
Console con=System.console();
String confirmPassword;
BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
int destinationAccountNum;
float amount;
System.out.print("Enter the account number to send money :");
destinationAccountNum=Integer.parseInt(br.readLine());
System.out.print("Enter the Amount to send :");
amount=Float.parseFloat(br.readLine());
System.out.print("Enter the password :");
confirmPassword=String.valueOf(con.readPassword());
if(!confirmPassword.equals(customer.getPassword()))
{
System.out.println("Invalid password");
return;
}

float currentBalance=customer.getAccount().getBalance();
if(currentBalance<amount)
{
System.out.println("Insufficient Balance to perform transaction");
return;
}
System.out.println("Money Send successfully to :"+destinationAccountNum);
customer.getAccount().setBalance(currentBalance-amount);
System.out.println("Your current Balance is :"+customer.getAccount().getBalance());
System.out.println("-----------------------------------------");
}catch(IOException e)
{
System.out.println(e);
}
}
public static void checkBalance(Customer customer)
{
System.out.println("-------Customer Balance check-----------");
System.out.println("Customer Name :"+customer.getName());
System.out.println("Balance is    :"+customer.getAccount().getBalance());
System.out.println("--------------------------------------");
}

}