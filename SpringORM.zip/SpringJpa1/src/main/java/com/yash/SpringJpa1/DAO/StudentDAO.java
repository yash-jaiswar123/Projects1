package com.yash.SpringJpa1.DAO;

public class StudentDAO {

	
}
