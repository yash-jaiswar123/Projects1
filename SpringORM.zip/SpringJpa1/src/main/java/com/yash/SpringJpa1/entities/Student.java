package com.yash.SpringJpa1.entities;

public class Student {
}
