package com.yash.SpringHibernate1.DAO;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.orm.hibernate5.HibernateTemplate;

import com.yash.SpringHibernate1.entities.Student;

public class StudentDAO {
private HibernateTemplate htemp;

	public HibernateTemplate getHtemp() {
	return htemp;
}

public void setHtemp(HibernateTemplate htemp) {
	this.htemp = htemp;
}
	@Transactional
	public int insert(Student student)
{
	int i=(Integer)this.htemp.save(student);
	return i;
}
	@Transactional
	public void update(Student student)
	{
		this.htemp.update(student);
		System.out.println("Data updated");
	}
	@Transactional
	public void delete(Student s)
	{
		this.htemp.delete(s);
		System.out.println("Data deleted");
	}
	public Student getData(int id)
	{
		Student s=this.htemp.get(Student.class,id);
		return s;
	}
	
	public List<Student> getAll()
	{
		List<Student> lst=this.htemp.loadAll(Student.class);
		return lst;
	}
}
