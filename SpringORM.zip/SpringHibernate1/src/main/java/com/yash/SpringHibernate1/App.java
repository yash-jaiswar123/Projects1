package com.yash.SpringHibernate1;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.yash.SpringHibernate1.DAO.StudentDAO;
import com.yash.SpringHibernate1.entities.Student;

import java.util.List;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        ApplicationContext context=new ClassPathXmlApplicationContext("config.xml");
        StudentDAO s=context.getBean("studentDao",StudentDAO.class);
        /*Student stu=new Student();
        stu.setId(6);
        stu.setName("yash");
        int i=s.insert(stu);
        System.out.println(i+" Data inserted");
        stu.setId(2);
        stu.setName("saoni");
        s.update(stu);
        
        stu.setId(5);
       // stu.setName("saoni");
        s.delete(stu);*/
        List<Student> lst=s.getAll();
        for(Student st:lst)
        System.out.println(st);
        
    }
    
}
