package com.yash.SpringHibernate1.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="studentDetails")
public class Student {
	@Id
	@Column(name="studentId")
private int id;
	@Column(name="studentName")
private String name;
	
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
	
}
